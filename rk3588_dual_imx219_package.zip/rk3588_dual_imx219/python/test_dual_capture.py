#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""同时抓取两路IMX219的1帧NV12并转换为JPG。"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np


def capture_one(device: str, output: Path, width: int, height: int, fps: int, warmup: int) -> subprocess.Popen:
    command = [
        "v4l2-ctl",
        "-d",
        device,
        f"--set-fmt-video=width={width},height={height},pixelformat=NV12",
        f"--set-parm={fps}",
        "--stream-mmap=4",
        f"--stream-skip={warmup}",
        "--stream-count=1",
        "--stream-poll",
        f"--stream-to={output}",
    ]
    print("执行：", " ".join(command))
    return subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def nv12_to_bgr(path: Path, width: int, height: int) -> np.ndarray:
    expected = width * height * 3 // 2
    data = np.fromfile(path, dtype=np.uint8)
    if data.size != expected:
        raise RuntimeError(f"{path} 大小错误：实际{data.size}字节，预期{expected}字节")
    nv12 = data.reshape(height * 3 // 2, width)
    return cv2.cvtColor(nv12, cv2.COLOR_YUV2BGR_NV12)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--left", default="/dev/video22")
    parser.add_argument("--right", default="/dev/video31")
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--out", type=Path, default=Path("/root/yolov8_rk3588/dual_capture_test"))
    args = parser.parse_args()

    for device in (args.left, args.right):
        if not Path(device).exists():
            raise FileNotFoundError(f"设备不存在：{device}")

    args.out.mkdir(parents=True, exist_ok=True)
    left_nv12 = args.out / "left.nv12"
    right_nv12 = args.out / "right.nv12"

    left_proc = capture_one(args.left, left_nv12, args.width, args.height, args.fps, args.warmup)
    right_proc = capture_one(args.right, right_nv12, args.width, args.height, args.fps, args.warmup)

    left_stdout, left_stderr = left_proc.communicate(timeout=30)
    right_stdout, right_stderr = right_proc.communicate(timeout=30)

    if left_proc.returncode != 0:
        raise RuntimeError(f"左相机抓图失败：\n{left_stdout}\n{left_stderr}")
    if right_proc.returncode != 0:
        raise RuntimeError(f"右相机抓图失败：\n{right_stdout}\n{right_stderr}")

    left = nv12_to_bgr(left_nv12, args.width, args.height)
    right = nv12_to_bgr(right_nv12, args.width, args.height)

    cv2.putText(left, "LEFT / CAMERA1 / video22", (30, 55), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 255), 3, cv2.LINE_AA)
    cv2.putText(right, "RIGHT / CAMERA2 / video31", (30, 55), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 255), 3, cv2.LINE_AA)

    left_jpg = args.out / "left.jpg"
    right_jpg = args.out / "right.jpg"
    pair_jpg = args.out / "pair.jpg"

    if not cv2.imwrite(str(left_jpg), left):
        raise RuntimeError("left.jpg保存失败")
    if not cv2.imwrite(str(right_jpg), right):
        raise RuntimeError("right.jpg保存失败")

    pair = np.hstack((left, right))
    pair_preview = cv2.resize(pair, (1280, 360), interpolation=cv2.INTER_AREA)
    if not cv2.imwrite(str(pair_jpg), pair_preview):
        raise RuntimeError("pair.jpg保存失败")

    print("\n双路抓图成功")
    print(f"左图：{left_jpg}")
    print(f"右图：{right_jpg}")
    print(f"合并图：{pair_jpg}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"失败：{exc}", file=sys.stderr)
        raise SystemExit(1)
