#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
RK3588 + 双IMX219 + YOLOv8 RKNN 实时检测（基线版）

左相机：CAMERA1 -> /dev/video22
右相机：CAMERA2 -> /dev/video31
模型：/root/yolov8_rk3588/int8_best.rknn
网页：http://板子IP:8080/

设计原则：
1. 两路相机持续采集，只保留最新帧，旧帧直接丢弃，避免延迟积压。
2. 一个RKNNLite实例轮流检测左右图，优先保证稳定性。
3. 采集保持1920x1080@30FPS；模型输入默认640x640。
4. 网页预览缩小后再JPEG编码，降低CPU和网络开销。
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from rknnlite.api import RKNNLite


CLASS_NAMES = ["100- O-O-S"]
IMAGE_SIZE = 640
CONF_THRESHOLD = 0.25
NMS_THRESHOLD = 0.45


def letterbox(image: np.ndarray, size: int = 640, color=(0, 0, 0)):
    original_height, original_width = image.shape[:2]
    ratio = min(size / original_height, size / original_width)
    resized_width = int(round(original_width * ratio))
    resized_height = int(round(original_height * ratio))
    resized = cv2.resize(image, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR)
    padding_width = size - resized_width
    padding_height = size - resized_height
    dw = padding_width / 2
    dh = padding_height / 2
    left = int(round(dw - 0.1))
    right = int(round(dw + 0.1))
    top = int(round(dh - 0.1))
    bottom = int(round(dh + 0.1))
    padded = cv2.copyMakeBorder(resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)
    return padded, ratio, (dw, dh)


def softmax(data: np.ndarray, axis: int):
    data = data - np.max(data, axis=axis, keepdims=True)
    exp_data = np.exp(data)
    return exp_data / np.sum(exp_data, axis=axis, keepdims=True)


def dfl(position: np.ndarray):
    batch, channels, height, width = position.shape
    if channels % 4 != 0:
        raise ValueError(f"DFL边框通道数必须能被4整除，当前为：{channels}")
    reg_max = channels // 4
    position = position.reshape(batch, 4, reg_max, height, width)
    position = softmax(position, axis=2)
    project = np.arange(reg_max, dtype=np.float32).reshape(1, 1, reg_max, 1, 1)
    return np.sum(position * project, axis=2)


def box_process(position: np.ndarray):
    grid_height = position.shape[2]
    grid_width = position.shape[3]
    grid_x, grid_y = np.meshgrid(
        np.arange(grid_width, dtype=np.float32),
        np.arange(grid_height, dtype=np.float32),
    )
    grid = np.stack((grid_x, grid_y), axis=0).reshape(1, 2, grid_height, grid_width)
    stride = np.array(
        [IMAGE_SIZE / grid_width, IMAGE_SIZE / grid_height], dtype=np.float32
    ).reshape(1, 2, 1, 1)
    position = dfl(position.astype(np.float32))
    top_left = grid + 0.5 - position[:, 0:2, :, :]
    bottom_right = grid + 0.5 + position[:, 2:4, :, :]
    return np.concatenate((top_left * stride, bottom_right * stride), axis=1)


def flatten_output(data: np.ndarray):
    channels = data.shape[1]
    return data.transpose(0, 2, 3, 1).reshape(-1, channels)


def nms(boxes: np.ndarray, scores: np.ndarray, threshold: float):
    if len(boxes) == 0:
        return np.empty((0,), dtype=np.int64)
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    widths = np.maximum(0.0, x2 - x1)
    heights = np.maximum(0.0, y2 - y1)
    areas = widths * heights
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        current = order[0]
        keep.append(current)
        if order.size == 1:
            break
        xx1 = np.maximum(x1[current], x1[order[1:]])
        yy1 = np.maximum(y1[current], y1[order[1:]])
        xx2 = np.minimum(x2[current], x2[order[1:]])
        yy2 = np.minimum(y2[current], y2[order[1:]])
        inter = np.maximum(0.0, xx2 - xx1) * np.maximum(0.0, yy2 - yy1)
        union = areas[current] + areas[order[1:]] - inter + 1e-7
        iou = inter / union
        valid = np.where(iou <= threshold)[0]
        order = order[valid + 1]
    return np.asarray(keep, dtype=np.int64)


def classwise_nms(boxes, class_ids, scores):
    final_boxes, final_classes, final_scores = [], [], []
    for class_id in np.unique(class_ids):
        indices = np.where(class_ids == class_id)[0]
        keep = nms(boxes[indices], scores[indices], NMS_THRESHOLD)
        if keep.size == 0:
            continue
        final_boxes.append(boxes[indices][keep])
        final_classes.append(class_ids[indices][keep])
        final_scores.append(scores[indices][keep])
    if not final_boxes:
        return None, None, None
    return (
        np.concatenate(final_boxes),
        np.concatenate(final_classes),
        np.concatenate(final_scores),
    )


def postprocess_nine_outputs(outputs):
    if len(outputs) != 9:
        raise ValueError(f"9输出后处理收到{len(outputs)}个输出")
    all_boxes, all_class_scores = [], []
    for branch_index in range(3):
        box_output = np.asarray(outputs[branch_index * 3], dtype=np.float32)
        class_output = np.asarray(outputs[branch_index * 3 + 1], dtype=np.float32)
        all_boxes.append(flatten_output(box_process(box_output)))
        all_class_scores.append(flatten_output(class_output))
    boxes = np.concatenate(all_boxes, axis=0)
    class_scores = np.concatenate(all_class_scores, axis=0)
    class_ids = np.argmax(class_scores, axis=1)
    scores = np.max(class_scores, axis=1)
    valid = scores >= CONF_THRESHOLD
    boxes, class_ids, scores = boxes[valid], class_ids[valid], scores[valid]
    if len(boxes) == 0:
        return None, None, None
    return classwise_nms(boxes, class_ids, scores)


def postprocess_single_output(outputs):
    prediction = np.squeeze(np.asarray(outputs[0], dtype=np.float32))
    if prediction.ndim != 2:
        raise ValueError(f"无法处理单输出形状：{prediction.shape}")

    # 常见输出：(4+nc, 8400) 或 (8400, 4+nc)
    expected_channels = 4 + len(CLASS_NAMES)
    if prediction.shape[0] == expected_channels:
        prediction = prediction.T
    elif prediction.shape[1] != expected_channels:
        # 对未知类别数也尽量兼容：较小维通常为通道维
        if prediction.shape[0] < prediction.shape[1]:
            prediction = prediction.T

    if prediction.shape[1] < 5:
        raise ValueError(f"单输出通道数不足：{prediction.shape}")

    boxes_xywh = prediction[:, :4]
    class_scores = prediction[:, 4:]
    class_ids = np.argmax(class_scores, axis=1)
    scores = np.max(class_scores, axis=1)
    valid = scores >= CONF_THRESHOLD
    boxes_xywh, class_ids, scores = boxes_xywh[valid], class_ids[valid], scores[valid]
    if len(boxes_xywh) == 0:
        return None, None, None

    boxes = np.empty_like(boxes_xywh)
    boxes[:, 0] = boxes_xywh[:, 0] - boxes_xywh[:, 2] / 2
    boxes[:, 1] = boxes_xywh[:, 1] - boxes_xywh[:, 3] / 2
    boxes[:, 2] = boxes_xywh[:, 0] + boxes_xywh[:, 2] / 2
    boxes[:, 3] = boxes_xywh[:, 1] + boxes_xywh[:, 3] / 2
    return classwise_nms(boxes, class_ids, scores)


def restore_boxes(boxes, ratio, padding, original_shape):
    if boxes is None:
        return None
    dw, dh = padding
    original_height, original_width = original_shape[:2]
    boxes = boxes.copy()
    boxes[:, [0, 2]] = (boxes[:, [0, 2]] - dw) / ratio
    boxes[:, [1, 3]] = (boxes[:, [1, 3]] - dh) / ratio
    boxes[:, [0, 2]] = np.clip(boxes[:, [0, 2]], 0, original_width - 1)
    boxes[:, [1, 3]] = np.clip(boxes[:, [1, 3]], 0, original_height - 1)
    return boxes


def draw_detections(image, boxes, class_ids, scores):
    if boxes is None:
        return image
    for box, class_id, score in zip(boxes, class_ids, scores):
        class_id = int(class_id)
        x1, y1, x2, y2 = box.astype(int)
        class_name = CLASS_NAMES[class_id] if 0 <= class_id < len(CLASS_NAMES) else f"class{class_id}"
        label = f"{class_name} {score:.2f}"
        cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(image, label, (x1, max(24, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2, cv2.LINE_AA)
    return image


def initialize_rknn(model_path: Path):
    rknn = RKNNLite()
    print(f"加载模型：{model_path}")
    ret = rknn.load_rknn(str(model_path))
    if ret != 0:
        raise RuntimeError(f"加载RKNN模型失败，返回值：{ret}")
    try:
        ret = rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0_1_2)
    except (AttributeError, TypeError):
        ret = rknn.init_runtime()
    if ret != 0:
        rknn.release()
        raise RuntimeError(f"初始化NPU失败，返回值：{ret}")
    return rknn


def read_exact(stream, size: int):
    chunks = []
    remaining = size
    while remaining > 0:
        chunk = stream.read(remaining)
        if not chunk:
            return None
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


class FrameSlot:
    def __init__(self, name: str):
        self.name = name
        self.lock = threading.Lock()
        self.frame: Optional[np.ndarray] = None
        self.sequence = -1
        self.timestamp = 0.0
        self.error: Optional[str] = None

    def update(self, frame: np.ndarray, timestamp: float):
        with self.lock:
            self.frame = frame
            self.sequence += 1
            self.timestamp = timestamp

    def get_latest(self):
        with self.lock:
            return self.frame, self.sequence, self.timestamp

    def set_error(self, message: str):
        with self.lock:
            self.error = message

    def get_error(self):
        with self.lock:
            return self.error


@dataclass
class DetectionState:
    boxes: Optional[np.ndarray] = None
    class_ids: Optional[np.ndarray] = None
    scores: Optional[np.ndarray] = None
    frame_sequence: int = -1
    timestamp: float = 0.0
    inference_ms: float = 0.0
    inference_fps: float = 0.0
    detection_count: int = 0


class DetectionSlot:
    def __init__(self):
        self.lock = threading.Lock()
        self.state = DetectionState()
        self.last_update_time: Optional[float] = None

    def update(self, boxes, class_ids, scores, frame_sequence: int, inference_ms: float):
        now = time.monotonic()
        with self.lock:
            fps = self.state.inference_fps
            if self.last_update_time is not None:
                instant = 1.0 / max(now - self.last_update_time, 1e-6)
                fps = instant if fps <= 0 else fps * 0.85 + instant * 0.15
            self.last_update_time = now
            self.state = DetectionState(
                boxes=boxes,
                class_ids=class_ids,
                scores=scores,
                frame_sequence=frame_sequence,
                timestamp=now,
                inference_ms=inference_ms,
                inference_fps=fps,
                detection_count=0 if boxes is None else len(boxes),
            )

    def get_latest(self):
        with self.lock:
            return self.state


class V4L2CaptureWorker(threading.Thread):
    def __init__(self, name, device, width, height, fps, warmup, buffers, frame_slot, stop_event):
        super().__init__(name=f"capture-{name}", daemon=True)
        self.camera_name = name
        self.device = device
        self.width = width
        self.height = height
        self.fps = fps
        self.warmup = warmup
        self.buffers = buffers
        self.frame_slot = frame_slot
        self.stop_event = stop_event
        self.frame_size = width * height * 3 // 2
        self.process: Optional[subprocess.Popen] = None
        self.log_path = Path(f"/tmp/{name.lower()}_camera_v4l2.log")

    def stop(self):
        process = self.process
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()

    def run(self):
        command = [
            "v4l2-ctl",
            "-d",
            self.device,
            f"--set-fmt-video=width={self.width},height={self.height},pixelformat=NV12",
            f"--set-parm={self.fps}",
            f"--stream-mmap={self.buffers}",
            f"--stream-skip={self.warmup}",
            "--stream-poll",
            "--stream-to=-",
        ]
        print(f"[{self.camera_name}] 采集命令：{' '.join(command)}")
        try:
            self.log_path.unlink(missing_ok=True)
            with self.log_path.open("w", encoding="utf-8") as log_file:
                self.process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=log_file, bufsize=0)
                if self.process.stdout is None:
                    raise RuntimeError("无法读取v4l2-ctl输出")
                while not self.stop_event.is_set():
                    frame_bytes = read_exact(self.process.stdout, self.frame_size)
                    if frame_bytes is None:
                        if self.stop_event.is_set():
                            break
                        log_file.flush()
                        log_text = self.log_path.read_text(encoding="utf-8", errors="replace")[-3000:] if self.log_path.exists() else ""
                        raise RuntimeError(f"摄像头数据流中断；退出码={self.process.poll()}\n{log_text}")
                    raw = np.frombuffer(frame_bytes, dtype=np.uint8)
                    nv12 = raw.reshape(self.height * 3 // 2, self.width)
                    bgr = cv2.cvtColor(nv12, cv2.COLOR_YUV2BGR_NV12)
                    self.frame_slot.update(bgr, time.monotonic())
        except Exception as exc:
            if not self.stop_event.is_set():
                message = f"{self.camera_name}采集失败：{exc}"
                self.frame_slot.set_error(message)
                print(message, file=sys.stderr)
        finally:
            self.stop()


class InferenceWorker(threading.Thread):
    def __init__(self, rknn, sources, stop_event):
        super().__init__(name="dual-yolo-inference", daemon=True)
        self.rknn = rknn
        self.sources = sources
        self.stop_event = stop_event
        self.error: Optional[str] = None
        self.printed_shapes = False

    def infer_one(self, frame):
        input_image, ratio, padding = letterbox(frame, IMAGE_SIZE, color=(0, 0, 0))
        input_image = cv2.cvtColor(input_image, cv2.COLOR_BGR2RGB)
        input_tensor = np.expand_dims(input_image, axis=0)
        start = time.perf_counter()
        outputs = self.rknn.inference(inputs=[input_tensor])
        inference_ms = (time.perf_counter() - start) * 1000.0
        if outputs is None:
            raise RuntimeError("RKNN inference返回None")
        if not self.printed_shapes:
            print("\n========== RKNN模型输出 ==========")
            print(f"输出数量：{len(outputs)}")
            for index, output in enumerate(outputs):
                print(f"output[{index}]：{np.asarray(output).shape}")
            self.printed_shapes = True
        if len(outputs) == 9:
            boxes, class_ids, scores = postprocess_nine_outputs(outputs)
        elif len(outputs) == 1:
            boxes, class_ids, scores = postprocess_single_output(outputs)
        else:
            shapes = [np.asarray(item).shape for item in outputs]
            raise RuntimeError(f"不支持当前模型输出：数量={len(outputs)}，形状={shapes}")
        boxes = restore_boxes(boxes, ratio, padding, frame.shape)
        return boxes, class_ids, scores, inference_ms

    def run(self):
        last_sequences = {name: -1 for name, _, _ in self.sources}
        try:
            while not self.stop_event.is_set():
                processed = False
                for name, frame_slot, detection_slot in self.sources:
                    if self.stop_event.is_set():
                        break
                    frame, sequence, _ = frame_slot.get_latest()
                    if frame is None or sequence == last_sequences[name]:
                        continue
                    last_sequences[name] = sequence
                    boxes, class_ids, scores, inference_ms = self.infer_one(frame)
                    detection_slot.update(boxes, class_ids, scores, sequence, inference_ms)
                    processed = True
                if not processed:
                    time.sleep(0.002)
        except Exception as exc:
            self.error = f"YOLO推理线程失败：{exc}"
            print(self.error, file=sys.stderr)
            self.stop_event.set()


class OutputStore:
    def __init__(self):
        self.condition = threading.Condition()
        self.jpeg: Optional[bytes] = None
        self.version = 0
        self.status = {"state": "starting"}

    def update(self, jpeg: bytes, status: dict):
        with self.condition:
            self.jpeg = jpeg
            self.status = status
            self.version += 1
            self.condition.notify_all()

    def wait_for_jpeg(self, previous_version: int, timeout=2.0):
        with self.condition:
            self.condition.wait_for(lambda: self.version != previous_version, timeout=timeout)
            return self.jpeg, self.version

    def get_status(self):
        with self.condition:
            return dict(self.status)


def put_text(image, text, position, scale=0.65):
    cv2.putText(image, text, position, cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(image, text, position, cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 255, 255), 2, cv2.LINE_AA)


def atomic_imwrite(path: Path, image: np.ndarray, quality=92):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.stem + ".tmp" + path.suffix)
    if not cv2.imwrite(str(temporary), image, [cv2.IMWRITE_JPEG_QUALITY, quality]):
        raise RuntimeError(f"保存图片失败：{temporary}")
    os.replace(temporary, path)


class PreviewWorker(threading.Thread):
    def __init__(self, left_frame, right_frame, left_det, right_det, output_store, result_dir, display_fps, preview_width, jpeg_quality, save_interval, stop_event):
        super().__init__(name="dual-preview", daemon=True)
        self.left_frame = left_frame
        self.right_frame = right_frame
        self.left_det = left_det
        self.right_det = right_det
        self.output_store = output_store
        self.result_dir = result_dir
        self.display_fps = display_fps
        self.preview_width = preview_width
        self.jpeg_quality = jpeg_quality
        self.save_interval = save_interval
        self.stop_event = stop_event
        self.error: Optional[str] = None
        self.measured_fps = 0.0
        self.last_display_time: Optional[float] = None

    def draw_one(self, frame, sequence, frame_ts, det: DetectionState, title, device):
        if frame is None:
            blank = np.zeros((int(self.preview_width * 9 / 16), self.preview_width, 3), dtype=np.uint8)
            put_text(blank, f"{title}: waiting...", (20, 40))
            return blank, None
        result = draw_detections(frame.copy(), det.boxes, det.class_ids, det.scores)
        now = time.monotonic()
        capture_age = max(0.0, now - frame_ts) * 1000
        result_age = max(0.0, now - det.timestamp) * 1000 if det.timestamp > 0 else -1
        lines = [
            f"{title}  {device}",
            f"Capture seq: {sequence}  age: {capture_age:.0f} ms",
            f"YOLO: {det.inference_fps:.1f} FPS  {det.inference_ms:.1f} ms",
            f"Detections: {det.detection_count}  result age: {result_age:.0f} ms",
        ]
        y = 32
        for line in lines:
            put_text(result, line, (12, y), 0.62)
            y += 30
        h, w = result.shape[:2]
        preview_height = int(round(h * self.preview_width / w))
        preview = cv2.resize(result, (self.preview_width, preview_height), interpolation=cv2.INTER_AREA)
        return preview, result

    def run(self):
        interval = 1.0 / max(self.display_fps, 1.0)
        next_time = time.monotonic()
        last_save = 0.0
        try:
            self.result_dir.mkdir(parents=True, exist_ok=True)
            while not self.stop_event.is_set():
                now = time.monotonic()
                if now < next_time:
                    time.sleep(next_time - now)
                current = time.monotonic()
                next_time = current + interval

                left_frame, left_seq, left_ts = self.left_frame.get_latest()
                right_frame, right_seq, right_ts = self.right_frame.get_latest()
                left_det = self.left_det.get_latest()
                right_det = self.right_det.get_latest()

                left_preview, left_full = self.draw_one(left_frame, left_seq, left_ts, left_det, "LEFT / CAMERA1", "/dev/video22")
                right_preview, right_full = self.draw_one(right_frame, right_seq, right_ts, right_det, "RIGHT / CAMERA2", "/dev/video31")
                combined = np.hstack((left_preview, right_preview))

                if self.last_display_time is not None:
                    instant = 1.0 / max(current - self.last_display_time, 1e-6)
                    self.measured_fps = instant if self.measured_fps <= 0 else self.measured_fps * 0.9 + instant * 0.1
                self.last_display_time = current

                success, encoded = cv2.imencode(".jpg", combined, [cv2.IMWRITE_JPEG_QUALITY, self.jpeg_quality])
                if not success:
                    raise RuntimeError("实时JPEG编码失败")

                status = {
                    "state": "running",
                    "time": datetime.now().isoformat(timespec="seconds"),
                    "display_fps": round(self.measured_fps, 2),
                    "left": {"device": "/dev/video22", "capture_sequence": left_seq, "inference_fps": round(left_det.inference_fps, 2), "inference_ms": round(left_det.inference_ms, 2), "detections": left_det.detection_count},
                    "right": {"device": "/dev/video31", "capture_sequence": right_seq, "inference_fps": round(right_det.inference_fps, 2), "inference_ms": round(right_det.inference_ms, 2), "detections": right_det.detection_count},
                }
                self.output_store.update(encoded.tobytes(), status)

                if self.save_interval > 0 and current - last_save >= self.save_interval:
                    if left_full is not None:
                        atomic_imwrite(self.result_dir / "latest_left.jpg", left_full)
                    if right_full is not None:
                        atomic_imwrite(self.result_dir / "latest_right.jpg", right_full)
                    atomic_imwrite(self.result_dir / "latest_pair.jpg", combined)
                    last_save = current
        except Exception as exc:
            self.error = f"预览线程失败：{exc}"
            print(self.error, file=sys.stderr)
            self.stop_event.set()


def create_http_handler(output_store: OutputStore):
    class Handler(BaseHTTPRequestHandler):
        server_version = "RK3588-Dual-YOLO/1.0"

        def log_message(self, fmt, *args):
            return

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                self.send_index()
            elif self.path.startswith("/stream.mjpg"):
                self.send_stream()
            elif self.path.startswith("/snapshot.jpg"):
                self.send_snapshot()
            elif self.path.startswith("/status.json"):
                self.send_status()
            else:
                self.send_error(404, "Not Found")

        def send_index(self):
            html = """<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>RK3588双摄YOLO</title><style>body{margin:0;background:#101010;color:#eee;font-family:Arial;text-align:center}h2{margin:12px 0 6px}#status{margin:8px;font-family:monospace}img{max-width:98vw;max-height:82vh;border:1px solid #555}a{color:#74b9ff}</style></head><body><h2>RK3588 双IMX219 YOLOv8 实时检测</h2><div id='status'>正在连接……</div><img src='/stream.mjpg'><p><a href='/snapshot.jpg' target='_blank'>打开当前截图</a></p><script>async function u(){try{const r=await fetch('/status.json',{cache:'no-store'});const d=await r.json();const l=d.left||{},q=d.right||{};document.getElementById('status').textContent=`显示 ${d.display_fps??'-'} FPS | 左 ${l.inference_fps??'-'} FPS / ${l.detections??'-'}个 | 右 ${q.inference_fps??'-'} FPS / ${q.detections??'-'}个`;}catch(e){document.getElementById('status').textContent='状态连接失败';}}setInterval(u,1000);u();</script></body></html>"""
            body = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def send_stream(self):
            self.send_response(200)
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Pragma", "no-cache")
            self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
            self.end_headers()
            previous = -1
            try:
                while True:
                    jpeg, version = output_store.wait_for_jpeg(previous, timeout=2.0)
                    if jpeg is None or version == previous:
                        continue
                    previous = version
                    self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\n")
                    self.wfile.write(f"Content-Length: {len(jpeg)}\r\n\r\n".encode("ascii"))
                    self.wfile.write(jpeg)
                    self.wfile.write(b"\r\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return

        def send_snapshot(self):
            jpeg, _ = output_store.wait_for_jpeg(-1, timeout=2.0)
            if jpeg is None:
                self.send_error(503, "No frame available")
                return
            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(jpeg)))
            self.end_headers()
            self.wfile.write(jpeg)

        def send_status(self):
            body = json.dumps(output_store.get_status(), ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return Handler


class Server(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def parse_args():
    parser = argparse.ArgumentParser(description="RK3588双IMX219 YOLOv8 RKNN实时检测")
    parser.add_argument("--model", type=Path, default=Path("/root/yolov8_rk3588/int8_best.rknn"))
    parser.add_argument("--left", default="/dev/video22")
    parser.add_argument("--right", default="/dev/video31")
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--camera-fps", type=int, default=30)
    parser.add_argument("--display-fps", type=float, default=30.0)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--buffers", type=int, default=4)
    parser.add_argument("--input-size", type=int, default=640)
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--nms", type=float, default=0.45)
    parser.add_argument("--preview-width", type=int, default=640)
    parser.add_argument("--jpeg-quality", type=int, default=80)
    parser.add_argument("--result-dir", type=Path, default=Path("/root/yolov8_rk3588/result_dual_camera"))
    parser.add_argument("--save-interval", type=float, default=1.0)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    return parser.parse_args()


def main():
    global IMAGE_SIZE, CONF_THRESHOLD, NMS_THRESHOLD
    args = parse_args()
    IMAGE_SIZE = args.input_size
    CONF_THRESHOLD = args.conf
    NMS_THRESHOLD = args.nms

    if shutil.which("v4l2-ctl") is None:
        raise RuntimeError("找不到v4l2-ctl")
    if not args.model.exists():
        raise FileNotFoundError(f"模型不存在：{args.model}")
    for name, device in (("左相机", args.left), ("右相机", args.right)):
        if not Path(device).exists():
            raise FileNotFoundError(f"{name}设备不存在：{device}")

    print("========== 双摄运行配置 ==========")
    print(f"Python：{sys.executable}")
    print(f"OpenCV：{cv2.__version__}")
    print(f"模型：{args.model}")
    print(f"左相机：{args.left}")
    print(f"右相机：{args.right}")
    print(f"采集：{args.width}x{args.height}@{args.camera_fps} NV12")
    print(f"模型输入：{args.input_size}x{args.input_size}")
    print(f"CONF={args.conf}，NMS={args.nms}")

    rknn = initialize_rknn(args.model)
    stop_event = threading.Event()
    left_frame, right_frame = FrameSlot("LEFT"), FrameSlot("RIGHT")
    left_det, right_det = DetectionSlot(), DetectionSlot()
    output_store = OutputStore()

    left_capture = V4L2CaptureWorker("LEFT", args.left, args.width, args.height, args.camera_fps, args.warmup, args.buffers, left_frame, stop_event)
    right_capture = V4L2CaptureWorker("RIGHT", args.right, args.width, args.height, args.camera_fps, args.warmup, args.buffers, right_frame, stop_event)
    inference = InferenceWorker(rknn, [("LEFT", left_frame, left_det), ("RIGHT", right_frame, right_det)], stop_event)
    preview = PreviewWorker(left_frame, right_frame, left_det, right_det, output_store, args.result_dir, args.display_fps, args.preview_width, args.jpeg_quality, args.save_interval, stop_event)
    server = Server((args.host, args.port), create_http_handler(output_store))
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)

    def request_stop(signum=None, frame=None):
        stop_event.set()

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)

    try:
        left_capture.start()
        right_capture.start()
        inference.start()
        preview.start()
        server_thread.start()
        ips = subprocess.check_output(["hostname", "-I"], text=True).strip().split()
        print("\n========== 浏览器地址 ==========")
        for ip in ips or ["板子IP"]:
            print(f"http://{ip}:{args.port}/")
        print("按Ctrl+C停止。")

        while not stop_event.wait(1.0):
            errors = [left_frame.get_error(), right_frame.get_error(), inference.error, preview.error]
            errors = [item for item in errors if item]
            if errors:
                raise RuntimeError("\n".join(errors))
    finally:
        print("\n正在停止……")
        stop_event.set()
        left_capture.stop()
        right_capture.stop()
        server.shutdown()
        server.server_close()
        for worker in (left_capture, right_capture, inference, preview):
            worker.join(timeout=3)
        rknn.release()
        print("NPU资源已释放")
        print(f"结果目录：{args.result_dir}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\n程序运行失败：{exc}", file=sys.stderr)
        raise SystemExit(1)
