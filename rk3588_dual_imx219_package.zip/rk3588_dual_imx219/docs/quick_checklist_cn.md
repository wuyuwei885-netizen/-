# 双 IMX219 复现快速步骤清单

1. 断电插好 CAMERA1（左）和 CAMERA2（右）。
2. Host 编译：
   ```bash
   cd rk3588_dual_imx219_repro
   SDK_ROOT=/home/ao/RK3588SDK/rk3588_linux_release ./host/build_dual_imx219_boot.sh
   ```
3. 上传：
   ```bash
   scp /home/ao/RK3588SDK/rk3588_linux_release/output/firmware/boot-dual-imx219.img root@192.168.10.66:/userdata/camera_boot/
   scp board/*.sh root@192.168.10.66:/root/
   scp python/*.py root@192.168.10.66:/root/yolov8_rk3588/
   ```
4. Target 写入：
   ```bash
   ssh root@192.168.10.66
   chmod +x /root/flash_dual_imx219_sd.sh
   /root/flash_dual_imx219_sd.sh
   sync && reboot
   ```
5. 验证：
   ```bash
   /root/find_dual_camera_nodes.sh
   ```
   必须识别 `imx219 1-0010` 和 `imx219 3-0010`。
6. 双路抓图：
   ```bash
   cd /root/yolov8_rk3588
   source rknn310/bin/activate
   python -u test_dual_capture.py
   ```
7. 双摄 YOLO：
   ```bash
   python -u dual_yolov8_rknn_camera.py
   ```
8. 浏览器打开：`http://192.168.10.66:8080/`。
