#!/usr/bin/env bash
set -euo pipefail

SDK_ROOT="${SDK_ROOT:-/home/ao/RK3588SDK/rk3588_linux_release}"
DTS_SOURCE="${DTS_SOURCE:-$(cd "$(dirname "$0")/../dts" && pwd)/tl3588f-evm-dual-imx219.dts}"
DTS_NAME="tl3588f-evm-dual-imx219"
DEFCONFIG="$SDK_ROOT/device/rockchip/rk3588/tl3588_evm_defconfig"
DTS_DIR="$SDK_ROOT/kernel/arch/arm64/boot/dts/rockchip"
OUTPUT_DIR="$SDK_ROOT/output/firmware"
OUTPUT_IMAGE="$OUTPUT_DIR/boot-dual-imx219.img"

say() { printf '\n========== %s ==========\n' "$*"; }
fail() { echo "错误：$*" >&2; exit 1; }

say "1. 检查主机和SDK"
[ "$(uname -m)" = "x86_64" ] || fail "此脚本应在Ubuntu x86_64主机运行，当前架构：$(uname -m)"
[ -d "$SDK_ROOT" ] || fail "SDK目录不存在：$SDK_ROOT"
[ -x "$SDK_ROOT/build.sh" ] || fail "找不到可执行 build.sh：$SDK_ROOT/build.sh"
[ -f "$DEFCONFIG" ] || fail "找不到板级配置：$DEFCONFIG"
[ -f "$DTS_SOURCE" ] || fail "找不到双摄DTS：$DTS_SOURCE"
[ -f "$DTS_DIR/tl3588f-evm.dts" ] || fail "找不到基础设备树：$DTS_DIR/tl3588f-evm.dts"

echo "SDK_ROOT=$SDK_ROOT"
echo "DTS_SOURCE=$DTS_SOURCE"
echo "DEFCONFIG=$DEFCONFIG"

say "2. 复制双摄设备树"
install -m 0644 "$DTS_SOURCE" "$DTS_DIR/$DTS_NAME.dts"
sha256sum "$DTS_DIR/$DTS_NAME.dts"

say "3. 备份并修改板级配置"
BACKUP="$DEFCONFIG.before-dual-imx219.$(date +%Y%m%d-%H%M%S)"
cp -a "$DEFCONFIG" "$BACKUP"

# 注释所有未注释的RK_KERNEL_DTS_NAME，再追加本项目配置。
sed -i 's/^RK_KERNEL_DTS_NAME=/# &/' "$DEFCONFIG"
printf '\nRK_KERNEL_DTS_NAME="%s"\n' "$DTS_NAME" >> "$DEFCONFIG"

echo "配置备份：$BACKUP"
grep -n 'RK_KERNEL_DTS_NAME' "$DEFCONFIG" | tail -n 10

say "4. 重新选择板级配置"
cd "$SDK_ROOT"
./build.sh lunch:tl3588_evm_defconfig

say "5. 编译内核和boot.img"
./build.sh kernel

say "6. 查找并复制boot.img"
[ -f "$SDK_ROOT/kernel/boot.img" ] || fail "编译返回成功，但没有找到 $SDK_ROOT/kernel/boot.img"
mkdir -p "$OUTPUT_DIR"
cp -f "$SDK_ROOT/kernel/boot.img" "$OUTPUT_IMAGE"

ls -lh "$SDK_ROOT/kernel/boot.img" "$OUTPUT_IMAGE"
sha256sum "$OUTPUT_IMAGE" | tee "$OUTPUT_IMAGE.sha256"

echo
file "$OUTPUT_IMAGE" || true

echo
printf '编译完成：%s\n' "$OUTPUT_IMAGE"
printf '下一步上传：scp "%s" root@192.168.10.66:/userdata/camera_boot/\n' "$OUTPUT_IMAGE"
