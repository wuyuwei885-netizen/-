#!/usr/bin/env bash
set -euo pipefail

echo "========================================"
echo " 双IMX219 Media / ISP节点识别"
echo "========================================"

echo
echo "========== 传感器启动日志 =========="
dmesg | grep -E 'imx219 [0-9]+-0010: Model ID' || true
COUNT="$(dmesg | grep -Ec 'imx219 [0-9]+-0010: Model ID' || true)"
echo "IMX219数量：$COUNT"

echo
echo "========== V4L2完整设备列表 =========="
v4l2-ctl --list-devices

echo
echo "========== 每个Media拓扑摘要 =========="
for MEDIA in /dev/media*; do
    [ -e "$MEDIA" ] || continue
    echo
    echo "----------------------------------------"
    echo "MEDIA：$MEDIA"
    echo "----------------------------------------"
    media-ctl -p -d "$MEDIA" | grep -E 'driver|model|imx219|rkcif-mipi|rkisp_mainpath|rkisp_selfpath|rkisp0-vir|device node name' || true
done

echo
echo "========== 自动提取rkisp_mainpath =========="
for MEDIA in /dev/media*; do
    [ -e "$MEDIA" ] || continue
    TOPOLOGY="$(media-ctl -p -d "$MEDIA" 2>/dev/null || true)"
    MODEL="$(printf '%s\n' "$TOPOLOGY" | awk '/^model[[:space:]]/{print $2; exit}')"
    MAINPATH="$(printf '%s\n' "$TOPOLOGY" | awk '/entity [0-9]+: rkisp_mainpath/{found=1; next} found && /device node name/{print $4; exit}')"
    SENSOR="$(printf '%s\n' "$TOPOLOGY" | grep -oE 'imx219 [0-9]+-0010' | head -n 1 || true)"
    if [ -n "$MAINPATH" ]; then
        echo "MEDIA=$MEDIA"
        echo "MODEL=${MODEL:-未知}"
        echo "SENSOR=${SENSOR:-由CIF输入连接}"
        echo "MAINPATH=$MAINPATH"
        v4l2-ctl -d "$MAINPATH" --info 2>/dev/null | grep -E 'Driver name|Card type|Bus info' || true
        v4l2-ctl -d "$MAINPATH" --list-formats-ext 2>/dev/null | grep -E "NV12|1920x1080|Size:" | head -n 20 || true
        echo
    fi
done

echo "========== 当前项目已验证映射 =========="
echo "LEFT / CAMERA1 : /dev/video22"
echo "RIGHT / CAMERA2: /dev/video31"
echo "注意：若上面的自动提取结果不同，以本机实际MAINPATH为准。"
