#!/usr/bin/env bash
set -u
OUT="${1:-/userdata/dual_camera_diagnostics_$(date +%Y%m%d-%H%M%S).txt}"
{
    echo "========== DATE =========="
    date
    echo "========== WHO / HOST =========="
    whoami
    hostname
    uname -a
    echo "========== BOOT SOURCE =========="
    findmnt -no SOURCE /
    lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS
    echo "========== IMX219 / CSI / ISP DMESG =========="
    dmesg | grep -Ei 'imx219|csi2-dphy|rkcif|rkisp|mipi' | tail -n 400
    echo "========== VIDEO / MEDIA NODES =========="
    ls -l /dev/video* /dev/media* 2>/dev/null || true
    echo "========== V4L2 DEVICES =========="
    v4l2-ctl --list-devices
    echo "========== MEDIA TOPOLOGY =========="
    for dev in /dev/media*; do
        [ -e "$dev" ] || continue
        echo "---------- $dev ----------"
        media-ctl -p -d "$dev"
    done
} > "$OUT" 2>&1

echo "诊断文件：$OUT"
