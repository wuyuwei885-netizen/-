#!/usr/bin/env bash
set -euo pipefail

IMAGE="${1:-/userdata/camera_boot/boot-dual-imx219.img}"
TARGET="${TARGET:-/dev/mmcblk1p3}"
EXPECTED_ROOT="${EXPECTED_ROOT:-/dev/mmcblk1p6}"
BACKUP_DIR="${BACKUP_DIR:-/userdata/camera_backup}"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_IMAGE="$BACKUP_DIR/boot-sd-before-dual-$TIMESTAMP.img"

say() { printf '\n========== %s ==========\n' "$*"; }
fail() { echo "错误：$*" >&2; exit 1; }

say "TL3588F-EVM 双IMX219 boot安全写入"

say "1. 检查启动来源"
ROOT_SOURCE="$(findmnt -no SOURCE /)"
echo "当前根分区：$ROOT_SOURCE"
[ "$ROOT_SOURCE" = "$EXPECTED_ROOT" ] || fail "当前不是从 $EXPECTED_ROOT 启动，禁止继续，避免误写eMMC"

say "2. 检查目标分区"
[ -b "$TARGET" ] || fail "目标块设备不存在：$TARGET"
if findmnt "$TARGET" >/dev/null 2>&1; then
    fail "$TARGET 当前已挂载，禁止写入"
fi
TARGET_SIZE="$(blockdev --getsize64 "$TARGET")"
echo "目标分区：$TARGET"
echo "目标容量：$TARGET_SIZE 字节"

say "3. 检查双摄镜像"
[ -f "$IMAGE" ] || fail "镜像不存在：$IMAGE"
IMAGE_SIZE="$(stat -c '%s' "$IMAGE")"
IMAGE_SHA="$(sha256sum "$IMAGE" | awk '{print $1}')"
ls -lh "$IMAGE"
echo "镜像大小：$IMAGE_SIZE 字节"
echo "镜像SHA256：$IMAGE_SHA"
[ "$IMAGE_SIZE" -le "$TARGET_SIZE" ] || fail "镜像大于目标分区"

say "4. 备份当前SD卡boot分区"
mkdir -p "$BACKUP_DIR"
dd if="$TARGET" of="$BACKUP_IMAGE" bs=4M status=progress conv=fsync
BACKUP_SIZE="$(stat -c '%s' "$BACKUP_IMAGE")"
[ "$BACKUP_SIZE" -eq "$TARGET_SIZE" ] || fail "备份大小异常：$BACKUP_SIZE，预期：$TARGET_SIZE"
sha256sum "$BACKUP_IMAGE" | tee "$BACKUP_IMAGE.sha256"
echo "备份完成：$BACKUP_IMAGE"

say "5. 最终确认"
echo "镜像：$IMAGE"
echo "目标：$TARGET"
echo "备份：$BACKUP_IMAGE"
echo
echo "即将覆盖SD卡boot分区。"
read -r -p "请输入 WRITE_SD_BOOT 继续：" CONFIRM
[ "$CONFIRM" = "WRITE_SD_BOOT" ] || fail "用户取消"

say "6. 写入双摄boot.img"
dd if="$IMAGE" of="$TARGET" bs=4M status=progress conv=fsync
sync

say "7. 读取分区并校验"
READBACK_SHA="$(head -c "$IMAGE_SIZE" "$TARGET" | sha256sum | awk '{print $1}')"
echo "镜像SHA256：$IMAGE_SHA"
echo "回读SHA256：$READBACK_SHA"
[ "$READBACK_SHA" = "$IMAGE_SHA" ] || fail "回读校验失败，禁止重启；请立即恢复备份"

say "写入和校验成功"
echo "备份文件：$BACKUP_IMAGE"
echo "确认两颗IMX219排线已经插好后执行：sync && reboot"
