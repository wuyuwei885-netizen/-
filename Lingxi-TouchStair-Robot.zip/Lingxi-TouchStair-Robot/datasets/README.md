# Datasets

This directory only keeps dataset structure examples.

Do not upload the full dataset to GitHub.

Expected YOLO dataset:

```text
datasets/stair_handrail/
├── images/
│   ├── train/
│   ├── val/
│   └── test/
└── labels/
    ├── train/
    ├── val/
    └── test/
```

Class mapping:

```text
0 handrail
1 stairs
```
