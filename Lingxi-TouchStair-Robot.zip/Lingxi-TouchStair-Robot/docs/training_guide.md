# Training Guide

本文档说明如何训练“楼梯 + 栏杆”YOLO 检测模型。

---

## 1. 环境安装

```bash
python -m venv .venv
source .venv/bin/activate  # Windows 使用 .\.venv\Scripts\activate
pip install -r requirements.txt
```

确认 ultralytics 可用：

```bash
yolo version
```

---

## 2. 数据配置

数据配置文件：

```text
configs/data.yaml
```

内容：

```yaml
path: datasets/stair_handrail
train: images/train
val: images/val
test: images/test

names:
  0: handrail
  1: stairs
```

训练前检查数据集：

```bash
python scripts/check_yolo_dataset.py --dataset datasets/stair_handrail
```

---

## 3. MVP 训练命令

推荐先使用 YOLO11n：

```bash
yolo detect train data=configs/data.yaml model=yolo11n.pt epochs=100 imgsz=640 batch=16
```

输出目录通常为：

```text
runs/detect/train/
```

核心权重：

```text
runs/detect/train/weights/best.pt
```

---

## 4. 精度不足时的训练命令

如果 YOLO11n 检测效果不足，再尝试 YOLO11s：

```bash
yolo detect train data=configs/data.yaml model=yolo11s.pt epochs=100 imgsz=640 batch=16
```

注意：YOLO11s 参数量更大，上板推理速度和 BPU 转换风险都需要重新验证。

---

## 5. 推荐训练策略

### 5.1 先保证数据正确

不要在数据集还存在以下问题时调参：

- 类别 id 混乱；
- 缺少 label 文件；
- bbox 坐标越界；
- 负样本缺失；
- 图片文件名混乱；
- 标注边界不统一。

### 5.2 再调模型

顺序建议：

```text
检查数据集 -> 训练 YOLO11n -> PC 测试 -> 补数据 -> 再训练 -> 导出 ONNX -> BPU 转换
```

### 5.3 不要只看训练指标

必须保留 test 集，用真实楼梯图片测试：

```bash
python src/vision/yolo_infer_pc.py \
  --weights runs/detect/train/weights/best.pt \
  --source datasets/stair_handrail/images/test \
  --show
```

---

## 6. 常见训练问题

| 问题 | 可能原因 | 处理方法 |
|---|---|---|
| 训练后类别错乱 | `data.yaml` names 顺序与标签 id 不一致 | 固定 `0: handrail`、`1: stairs`，重新检查标签 |
| 墙面误检为楼梯 | 负样本不足 | 增加普通走廊、墙面、地面负样本 |
| 置信度低 | 数据量少、光照单一、标注不稳定 | 补充多场景数据，统一标注规范 |
| 上板卡顿 | 模型过大或输入尺寸过高 | 使用 YOLO11n，降低 imgsz，使用 BPU 推理 |
| 导出失败 | opset 或模型结构不兼容 | 固定 imgsz，使用受支持 opset，检查导出日志 |

---

## 7. 导出 ONNX

```bash
python scripts/export_onnx.py \
  --weights runs/detect/train/weights/best.pt \
  --imgsz 640 \
  --opset 11
```

导出的 `.onnx` 不上传 GitHub。

---

## 8. 模型文件管理

不要上传：

```text
*.pt
*.onnx
*.bin
runs/
```

只在 `models/README.md` 记录模型来源、训练日期、数据版本、指标和部署状态。
