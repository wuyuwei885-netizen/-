# Technical Route

本文档整理“灵犀·触行”项目的完整技术路线，覆盖数据、训练、导出、RDK X5 部署和后续视觉-雷达融合。

---

## 1. 数据采集

### 1.1 采集场景

数据来自真实校园环境，优先覆盖：

- 教学楼楼梯；
- 宿舍楼楼梯；
- 实验楼楼梯；
- 楼梯扶手 / 栏杆；
- 普通走廊；
- 墙面；
- 地面；
- 无楼梯、无栏杆负样本场景。

### 1.2 采集设备

可使用以下设备采集：

- USB 摄像头；
- 手机拍摄；
- RDK X5 外接摄像头；
- IMX219 摄像头；
- C100 摄像头。

### 1.3 数据规模目标

MVP 数据目标约为：

```text
1000 images
```

推荐分布：

| 数据类型 | 建议比例 | 说明 |
|---|---:|---|
| 楼梯正样本 | 40% | 包含近景、远景、上行、下行、侧视角 |
| 栏杆正样本 | 40% | 包含左侧、右侧、不同材质、不同高度 |
| 负样本 | 20% | 普通走廊、墙面、地面、无楼梯无栏杆 |

---

## 2. 数据标注

### 2.1 标注工具

使用 Label Studio 进行目标检测标注。

导出格式使用 YOLO 检测格式：

```text
<class_id> <x_center> <y_center> <width> <height>
```

所有坐标均为归一化坐标，范围为 `0~1`。

### 2.2 类别映射

最终训练类别统一为：

```yaml
names:
  0: handrail
  1: stairs
```

必须保持 `data.yaml`、标注文件、训练脚本中的类别顺序一致。

### 2.3 标注规范

#### handrail

- 只框栏杆主体连续区域。
- 不要把墙面、楼梯边缘、大面积背景框入 handrail。
- 栏杆被遮挡时，只框可见主体。
- 多段栏杆可分多个框，不强行框成一个超大框。

#### stairs

- 框台阶主要可见区域。
- 不要把整面墙、整条走廊、大面积地面都框入 stairs。
- 楼梯远景可以框整体台阶区域。
- 近景台阶可框主要台阶结构，不需要每一级台阶单独标注。

---

## 3. 数据清洗

### 3.1 曾经遇到的问题

| 问题 | 表现 |
|---|---|
| 数据量不足 | 模型训练后置信度低，泛化差 |
| 类别分布不平衡 | 某一类识别明显好，另一类漏检严重 |
| 负样本缺失 | 墙面、地面、走廊被误检为楼梯或栏杆 |
| 空标签处理不规范 | 训练或检查脚本找不到对应 label |
| 文件名乱码 | 中文路径、空格、特殊字符导致训练、导出异常 |
| 标注不统一 | stairs 和 handrail 边界忽大忽小，模型学习混乱 |
| 图片质量差 | 模糊、过暗、过曝、角度极端导致训练噪声增加 |

### 3.2 解决方法

- 按 `7:2:1` 划分 `train / val / test`。
- 保证正样本和负样本比例。
- 删除严重模糊、无法判断目标的图片。
- 统一英文文件名，例如 `stair_000001.jpg`。
- 检查 image 和 label 是否一一对应。
- 负样本允许空标签，但必须保留同名 `.txt` 文件。
- 使用脚本检查类别 id 是否越界。
- 使用脚本检查 bbox 是否为 5 列且坐标在 `0~1` 范围内。

---

## 4. 模型训练

### 4.1 训练框架

使用 Ultralytics YOLO。

项目曾考虑或尝试：

- YOLOv8；
- YOLO11n；
- YOLO11s。

### 4.2 模型选择策略

MVP 推荐使用：

```text
YOLO11n
```

原因：

- 参数量小；
- 推理速度更适合端侧设备；
- 更容易先跑通完整链路；
- 适合 RDK X5 BPU 部署验证。

如果 YOLO11n 精度不足，再尝试：

```text
YOLO11s
```

### 4.3 训练目标

训练输出：

```text
runs/detect/train/weights/best.pt
```

训练命令：

```bash
yolo detect train data=configs/data.yaml model=yolo11n.pt epochs=100 imgsz=640 batch=16
```

---

## 5. 模型导出

### 5.1 导出链路

```text
best.pt -> best.onnx
```

命令：

```bash
python scripts/export_onnx.py --weights runs/detect/train/weights/best.pt --imgsz 640 --opset 11
```

### 5.2 导出注意事项

- 固定输入尺寸，例如 `640x640`。
- 保持训练、导出、部署输入尺寸一致。
- opset 版本优先使用部署工具支持的版本。
- 导出后先在 PC 端验证 ONNX 是否可运行。
- 不要把 `.onnx` 上传到 GitHub。

---

## 6. RDK X5 端侧部署

### 6.1 部署链路

```text
best.pt
  -> export ONNX
  -> OpenExplorer / hb_compile
  -> handrail_stairs_yolo11n.bin
  -> RDK X5 BPU inference
```

### 6.2 RDK X5 端侧流程

1. 摄像头采集图像。
2. 图像 resize / normalize。
3. BPU 执行 BIN 模型推理。
4. 后处理解析检测框、类别、置信度。
5. Web overlay 或本地窗口显示结果。
6. 发布检测结果给后续融合或控制模块。

### 6.3 输出信息

每个检测目标输出：

```text
class_id
class_name
confidence
x1, y1, x2, y2
center_x, center_y
relative_position: left / center / right
```

其中 `relative_position` 是后续计划，当前仓库先提供基础代码结构。

---

## 7. 雷达融合

### 7.1 雷达设备

使用：

```text
Tmini Plus ToF LiDAR
```

### 7.2 ROS2 接入

后续计划通过 ROS2 接入雷达数据：

```text
/scan  sensor_msgs/LaserScan
```

### 7.3 融合思路

- 视觉负责识别语义目标：这是楼梯还是栏杆。
- 雷达负责测距和空间结构：前方是否有障碍，距离是否合理。
- 融合后输出更可靠的候选目标。

### 7.4 初始融合公式

```python
fusion_score = 0.6 * vision_score + 0.4 * radar_score
```

输出范围限制在：

```text
0 <= fusion_score <= 1
```

### 7.5 后续 ROS2 topic 设计

后续计划发布：

```text
/vision/stair_detections
/fusion/step_candidate
/fusion/step_confirmed
/fusion/handrail_candidate
```

---

## 8. 总体流程图

```text
Data Collection
    ↓
Label Studio Annotation
    ↓
YOLO Dataset Cleaning
    ↓
YOLO11n Training
    ↓
best.pt
    ↓
ONNX Export
    ↓
OpenExplorer / hb_compile
    ↓
RDK X5 BPU Inference
    ↓
Camera Real-time Detection
    ↓
Tmini Plus LiDAR Fusion
    ↓
Robot Motion / Flexible Tentacle Control
```
