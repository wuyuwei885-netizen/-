# Troubleshooting

本文档用于快速定位“灵犀·触行”项目中的常见问题。

---

## 1. 训练后类别错乱

### 表现

- 栏杆被识别为 stairs。
- 楼梯被识别为 handrail。
- 训练日志正常，但推理类别不对。

### 原因

- `data.yaml` 中类别顺序与标签 id 不一致。
- Label Studio 导出类别顺序发生变化。
- 部分标签文件 class_id 不是 `0` 或 `1`。

### 修复

```bash
python scripts/check_yolo_dataset.py --dataset datasets/stair_handrail
```

确保：

```yaml
names:
  0: handrail
  1: stairs
```

---

## 2. 墙面 / 地面 / 走廊误检

### 原因

负样本不足。

### 修复

补充负样本：

- 普通走廊；
- 墙面；
- 地面；
- 无楼梯无栏杆场景。

负样本需要同名空 `.txt`：

```text
negative_000001.jpg
negative_000001.txt
```

---

## 3. 训练脚本找不到标签

### 原因

图片和标签不同名，或 label 路径不符合 YOLO 结构。

### 修复

检查目录：

```text
images/train/xxx.jpg
labels/train/xxx.txt
```

执行：

```bash
python scripts/check_yolo_dataset.py --dataset datasets/stair_handrail
```

---

## 4. 中文路径导致异常

### 表现

- 文件读取失败；
- 导出失败；
- Docker / WSL / RDK X5 路径不兼容。

### 修复

批量重命名：

```bash
python scripts/rename_images.py --images datasets/raw/images --labels datasets/raw/labels --prefix stair
```

---

## 5. ONNX 导出失败

### 可能原因

- `ultralytics` 未安装；
- 权重路径错误；
- opset 不兼容；
- 输入尺寸设置不合理。

### 修复

```bash
pip install ultralytics onnx
python scripts/export_onnx.py --weights runs/detect/train/weights/best.pt --imgsz 640 --opset 11
```

---

## 6. BIN 转换失败

### 可能原因

- 输入尺寸不固定；
- 输入输出名称与配置不一致；
- 校准数据路径错误；
- 模型存在不支持算子；
- 预处理配置不一致。

### 修复思路

1. 先确认 ONNX 可正常推理。
2. 固定输入尺寸 `640x640`。
3. 检查 `configs/rdk_x5_compile_config.yaml`。
4. 使用真实楼梯场景图片作为校准数据。
5. 先用 YOLO11n，不要一开始使用大模型。

---

## 7. RDK X5 摄像头黑屏

### 检查设备

```bash
ls /dev/video*
v4l2-ctl --list-devices
```

### 测试 OpenCV

```bash
python src/vision/camera_test.py --camera 0
```

### 处理方法

- 更换 camera index，例如 `--camera 1`；
- 检查摄像头是否被占用；
- 更换 USB 摄像头；
- 降低分辨率；
- 确认权限。

---

## 8. 实时检测卡顿

### 原因

- 模型过大；
- 输入分辨率过高；
- CPU 后处理压力大；
- 可视化开销大；
- 未使用 BPU 推理。

### 修复

- 使用 YOLO11n；
- 输入尺寸先用 640；
- 减少显示窗口刷新和日志打印；
- 优先 BPU 推理；
- 必要时降低摄像头 FPS。

---

## 9. 检测置信度低

### 原因

- 数据集太小；
- 标注不稳定；
- 光照变化大；
- 栏杆材质差异大；
- 楼梯视角不够丰富。

### 修复

- 补充室内 / 室外数据；
- 补充远景 / 近景数据；
- 补充左侧 / 右侧栏杆；
- 清理模糊图片；
- 统一标注规范。

---

## 10. ROS2 融合没有结果

当前完整融合属于后续计划。排查顺序应为：

1. 摄像头检测是否单独正常；
2. `/scan` 是否有雷达数据；
3. 时间戳是否同步；
4. 检测框是否发布；
5. fusion node 是否订阅正确 topic；
6. fusion score 阈值是否过高。
