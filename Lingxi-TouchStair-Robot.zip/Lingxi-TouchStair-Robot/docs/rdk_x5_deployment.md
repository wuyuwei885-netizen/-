# RDK X5 Deployment

本文档整理 RDK X5 端侧部署思路。当前仓库提供部署说明和配置模板，实际 BIN 转换需在 RDK X5 / OpenExplorer 对应环境中完成。

---

## 1. 部署目标

将 PC 端训练得到的 YOLO 模型部署到 RDK X5 BPU 上，实现本地摄像头实时楼梯 / 栏杆检测。

部署链路：

```text
best.pt -> best.onnx -> handrail_stairs_yolo11n.bin -> RDK X5 BPU inference
```

---

## 2. 文件说明

| 文件 | 说明 | 是否上传 GitHub |
|---|---|---|
| `best.pt` | Ultralytics 训练得到的 PyTorch 权重 | 否 |
| `best.onnx` | 导出的 ONNX 模型 | 否 |
| `handrail_stairs_yolo11n.bin` | RDK X5 BPU 模型 | 否 |
| `configs/rdk_x5_compile_config.yaml` | BIN 转换配置模板 | 是 |
| `models/README.md` | 模型记录说明 | 是 |

---

## 3. ONNX 导出

在 PC / WSL 环境执行：

```bash
python scripts/export_onnx.py \
  --weights runs/detect/train/weights/best.pt \
  --imgsz 640 \
  --opset 11
```

得到：

```text
runs/detect/train/weights/best.onnx
```

---

## 4. BIN 转换注意事项

使用 OpenExplorer / `hb_compile` 转换时重点检查：

- 输入尺寸是否固定，例如 `1x3x640x640`；
- 模型输入名称是否和配置一致；
- 模型输出名称是否和配置一致；
- 校准数据是否存在；
- 校准图片是否与真实楼梯场景接近；
- opset 是否受支持；
- 是否存在 BPU 不支持的算子；
- 预处理参数是否与训练 / 导出保持一致。

配置模板见：

```text
configs/rdk_x5_compile_config.yaml
```

---

## 5. 摄像头测试

上板后先不要直接运行模型，先测试摄像头：

```bash
python src/vision/camera_test.py --camera 0
```

如果黑屏，检查：

```bash
ls /dev/video*
v4l2-ctl --list-devices
```

必要时安装：

```bash
sudo apt update
sudo apt install v4l-utils
```

---

## 6. 推理流程

RDK X5 上的目标推理流程：

```text
Camera frame
  -> resize / letterbox
  -> normalize / format convert
  -> BPU inference with .bin
  -> YOLO postprocess
  -> draw boxes / publish results
```

输出目标：

```text
class_name: handrail / stairs
confidence: 0~1
bbox: x1, y1, x2, y2
center: center_x, center_y
```

---

## 7. 当前状态与后续计划

当前仓库整理：

- YOLO 数据集检查脚本；
- ONNX 导出脚本；
- RDK X5 部署说明；
- BIN 转换配置模板；
- 摄像头测试脚本；
- PC 端推理脚本。

后续计划：

- 补充 RDK X5 实际 BPU 推理脚本；
- 补充 `.bin` 模型输入输出解析说明；
- 补充 Web overlay 演示代码；
- 补充 ROS2 topic 发布检测结果；
- 与 Tmini Plus ToF 雷达融合。
