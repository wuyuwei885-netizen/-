# Dataset Guide

本文档说明“灵犀·触行”项目的数据集构建、标注、清洗和检查规范。

---

## 1. 数据集目标

本项目检测两类目标：

| class_id | class_name | 说明 |
|---:|---|---|
| 0 | handrail | 楼梯栏杆 / 扶手主体区域 |
| 1 | stairs | 楼梯 / 台阶主要可见区域 |

数据集服务于真实校园楼梯场景，不使用 COCO 中的通用类别。

---

## 2. 推荐目录结构

```text
datasets/stair_handrail/
├── images/
│   ├── train/
│   ├── val/
│   └── test/
└── labels/
    ├── train/
    ├── val/
    └── test/
```

图片和标签必须同名：

```text
images/train/stair_000001.jpg
labels/train/stair_000001.txt
```

---

## 3. YOLO 标签格式

每一行表示一个目标框：

```text
<class_id> <x_center> <y_center> <width> <height>
```

所有坐标是归一化值，范围必须在 `0~1`。

正确示例：

```text
0 0.5123 0.4200 0.3000 0.1800
1 0.4800 0.6700 0.8200 0.3600
```

错误示例：

```text
2 0.5 0.5 0.3 0.2          # class_id 越界
0 320 240 100 50            # 不是归一化坐标
1 0.5 0.5 0.3               # 列数不足
stairs 0.5 0.5 0.3 0.2      # class_id 不能写字符串
```

---

## 4. 负样本规范

负样本是没有楼梯和栏杆的图片，例如：

- 普通走廊；
- 墙面；
- 地面；
- 教室门口；
- 无楼梯无栏杆场景。

负样本必须保留同名空标签文件：

```text
images/train/corridor_000001.jpg
labels/train/corridor_000001.txt
```

其中 `corridor_000001.txt` 内容为空。

这样做的原因是让模型学习“没有目标”的场景，减少误检。

---

## 5. 数据划分

推荐比例：

```text
train : val : test = 7 : 2 : 1
```

使用脚本：

```bash
python scripts/split_dataset.py \
  --src-images datasets/raw/images \
  --src-labels datasets/raw/labels \
  --out-dataset datasets/stair_handrail \
  --seed 42
```

---

## 6. 文件命名规范

不要使用：

- 中文文件名；
- 空格；
- 特殊符号；
- 过长文件名；
- 混乱编号。

推荐命名：

```text
stair_000001.jpg
stair_000002.jpg
handrail_000001.jpg
negative_000001.jpg
```

批量重命名：

```bash
python scripts/rename_images.py \
  --images datasets/raw/images \
  --labels datasets/raw/labels \
  --prefix stair \
  --digits 6
```

---

## 7. 数据检查

训练前必须执行：

```bash
python scripts/check_yolo_dataset.py --dataset datasets/stair_handrail
```

检查内容：

- `images` 和 `labels` 是否对应；
- 是否存在缺失标签；
- 是否存在缺失图片；
- label 是否为空；
- bbox 是否为 5 列；
- class_id 是否只包含 `0` 和 `1`；
- bbox 坐标是否在 `0~1`；
- `width` 和 `height` 是否大于 0。

---

## 8. 标注质量规范

### handrail

- 框栏杆主体，不框大面积背景。
- 被遮挡的栏杆只框可见部分。
- 多段栏杆可以分多个框。
- 左右两侧栏杆都要标注。

### stairs

- 框楼梯台阶主要可见区域。
- 不把整面墙、整条走廊当作 stairs。
- 不需要每一级台阶单独标注，除非项目后续明确需要台阶级检测。
- 远景楼梯可框整体区域。

---

## 9. 数据集不要上传到 GitHub

GitHub 仓库只保留数据集结构和少量示例，不上传完整数据集。

`.gitignore` 已排除：

```text
datasets/raw/
datasets/full/
*.zip
*.mp4
*.avi
```
