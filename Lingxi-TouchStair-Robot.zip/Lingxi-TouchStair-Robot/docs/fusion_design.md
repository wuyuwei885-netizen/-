# Vision-Radar Fusion Design

## 1. 设计目标

视觉-雷达融合模块用于将 YOLO 检测结果和 Tmini Plus ToF 激光雷达距离信息结合，为机器人上楼和柔性触手抓握提供更稳定的候选目标。

## 2. 传感器分工

| 模块 | 输入 | 输出 | 作用 |
|---|---|---|---|
| Camera + YOLO | 图像 | stairs / handrail 检测框 | 判断目标语义类别 |
| Tmini Plus ToF LiDAR | `/scan` | 距离 / 障碍结构 | 判断前方空间结构和距离 |
| Fusion | 检测框 + 距离 | candidate / confirmed | 输出更可靠的感知结果 |

## 3. 初始融合公式

```python
fusion_score = 0.6 * vision_score + 0.4 * radar_score
```

说明：

- `vision_score` 来自 YOLO confidence；
- `radar_score` 来自雷达距离、障碍稳定性、几何合理性；
- 输出限制在 `0~1`。

代码见：

```text
src/fusion/fusion_score.py
```

## 4. 后续 ROS2 topic

计划使用：

```text
/vision/stair_detections
/scan
/fusion/step_candidate
/fusion/step_confirmed
/fusion/handrail_candidate
```

## 5. 当前状态

当前仓库只提供融合评分函数和 ROS2 节点占位结构。Tmini Plus 雷达与视觉检测结果的完整同步融合属于后续计划。
