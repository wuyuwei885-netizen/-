# Models

This directory is used to record model information only.

Do not upload large model files to GitHub:

- `*.pt`
- `*.onnx`
- `*.bin`

Recommended local model names:

```text
best.pt
best.onnx
handrail_stairs_yolo11n.bin
```

Recommended model record table:

| Date | Dataset Version | Model | Input Size | Status | Notes |
|---|---|---|---:|---|---|
| 2026-xx-xx | v1 | YOLO11n | 640 | local only | trained on stair/handrail dataset |
