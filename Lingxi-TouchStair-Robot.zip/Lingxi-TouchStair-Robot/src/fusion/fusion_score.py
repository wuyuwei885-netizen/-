#!/usr/bin/env python3
"""
Simple vision-radar fusion score for Lingxi TouchStair Robot.

Default formula:
    fusion_score = 0.6 * vision_score + 0.4 * radar_score

Both input scores and output score are clipped to [0, 1].
"""

from __future__ import annotations

import argparse


def clamp01(value: float) -> float:
    """Clamp a number into [0, 1]."""
    return max(0.0, min(1.0, float(value)))


def compute_fusion_score(
    vision_score: float,
    radar_score: float,
    vision_weight: float = 0.6,
    radar_weight: float = 0.4,
) -> float:
    """
    Compute weighted fusion score.

    Args:
        vision_score: YOLO confidence or normalized vision confidence.
        radar_score: Normalized radar confidence based on distance/geometric consistency.
        vision_weight: Weight for vision score. Default: 0.6.
        radar_weight: Weight for radar score. Default: 0.4.

    Returns:
        A float in [0, 1].
    """
    v = clamp01(vision_score)
    r = clamp01(radar_score)

    total_weight = vision_weight + radar_weight
    if total_weight <= 0:
        raise ValueError("vision_weight + radar_weight must be > 0")

    score = (vision_weight * v + radar_weight * r) / total_weight
    return clamp01(score)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compute vision-radar fusion score.")
    parser.add_argument("--vision-score", type=float, required=True, help="Vision score in [0, 1].")
    parser.add_argument("--radar-score", type=float, required=True, help="Radar score in [0, 1].")
    parser.add_argument("--vision-weight", type=float, default=0.6, help="Vision weight. Default: 0.6")
    parser.add_argument("--radar-weight", type=float, default=0.4, help="Radar weight. Default: 0.4")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    score = compute_fusion_score(
        vision_score=args.vision_score,
        radar_score=args.radar_score,
        vision_weight=args.vision_weight,
        radar_weight=args.radar_weight,
    )
    print(f"fusion_score={score:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
