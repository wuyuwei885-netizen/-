#!/usr/bin/env python3
"""ROS2 stair fusion node placeholder for future vision-radar fusion."""

from __future__ import annotations


def main() -> None:
    print("TODO: subscribe detection results and LaserScan, then publish step_candidate / step_confirmed.")


if __name__ == "__main__":
    main()
