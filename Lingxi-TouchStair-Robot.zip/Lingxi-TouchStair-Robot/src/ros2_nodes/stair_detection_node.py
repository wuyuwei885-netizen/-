#!/usr/bin/env python3
"""ROS2 stair detection node placeholder for future RDK X5 integration."""

from __future__ import annotations


def main() -> None:
    print("TODO: publish YOLO stair/handrail detections as ROS2 messages.")


if __name__ == "__main__":
    main()
