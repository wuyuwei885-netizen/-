#!/usr/bin/env python3
"""
OpenCV camera test for PC / RDK X5.

Functions:
- Test whether a camera can be opened.
- Display real-time frames.
- Press q to quit.

Example:
    python src/vision/camera_test.py --camera 0
    python src/vision/camera_test.py --camera /dev/video0
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import cv2


def parse_camera(camera: str) -> int | str:
    if camera.isdigit():
        return int(camera)
    return camera


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Test camera with OpenCV.")
    parser.add_argument("--camera", type=str, default="0", help="Camera index or path. Default: 0")
    parser.add_argument("--width", type=int, default=640, help="Capture width. Default: 640")
    parser.add_argument("--height", type=int, default=480, help="Capture height. Default: 480")
    parser.add_argument("--fps", type=int, default=30, help="Capture FPS. Default: 30")
    parser.add_argument("--save-frame", type=Path, default=None, help="Optional path to save one frame when pressing s.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    camera_source = parse_camera(args.camera)

    cap = cv2.VideoCapture(camera_source)
    if not cap.isOpened():
        print(f"ERROR: failed to open camera: {args.camera}")
        print("Linux/RDK X5 debug commands:")
        print("  ls /dev/video*")
        print("  v4l2-ctl --list-devices")
        return 1

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
    cap.set(cv2.CAP_PROP_FPS, args.fps)

    print("Camera opened successfully.")
    print("Press q to quit. Press s to save one frame if --save-frame is set.")

    prev_time = time.time()
    fps_text = "FPS: --"

    while True:
        ok, frame = cap.read()
        if not ok or frame is None:
            print("WARNING: failed to read frame.")
            break

        now = time.time()
        dt = now - prev_time
        prev_time = now
        if dt > 0:
            fps_text = f"FPS: {1.0 / dt:.1f}"

        cv2.putText(frame, fps_text, (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        cv2.imshow("Lingxi Camera Test", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("s") and args.save_frame is not None:
            args.save_frame.parent.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(args.save_frame), frame)
            print(f"Saved frame to: {args.save_frame}")

    cap.release()
    cv2.destroyAllWindows()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
