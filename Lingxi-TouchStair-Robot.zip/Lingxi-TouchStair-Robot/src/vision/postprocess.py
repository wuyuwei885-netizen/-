"""Postprocess helpers for stair/handrail detection."""

from __future__ import annotations


def relative_position(center_x: float, image_width: float, left_ratio: float = 0.4, right_ratio: float = 0.6) -> str:
    """Return left / center / right according to bbox center_x and image width."""
    if image_width <= 0:
        raise ValueError("image_width must be > 0")
    ratio = center_x / image_width
    if ratio < left_ratio:
        return "left"
    if ratio > right_ratio:
        return "right"
    return "center"
