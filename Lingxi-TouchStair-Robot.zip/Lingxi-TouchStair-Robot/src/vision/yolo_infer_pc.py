#!/usr/bin/env python3
"""
PC-side YOLO inference before RDK X5 deployment.

Functions:
- Load best.pt or other Ultralytics YOLO weights.
- Run inference on image, directory, video or camera.
- Show and/or save detection results.

Examples:
    python src/vision/yolo_infer_pc.py --weights runs/detect/train/weights/best.pt --source datasets/stair_handrail/images/test --show
    python src/vision/yolo_infer_pc.py --weights runs/detect/train/weights/best.pt --source 0 --show
"""

from __future__ import annotations

import argparse
from pathlib import Path


def parse_source(source: str) -> int | str:
    if source.isdigit():
        return int(source)
    return source


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run YOLO inference on PC for stair/handrail detection.")
    parser.add_argument("--weights", type=Path, required=True, help="Path to YOLO weights, e.g. best.pt")
    parser.add_argument("--source", type=str, required=True, help="Image, directory, video path, or camera index such as 0")
    parser.add_argument("--imgsz", type=int, default=640, help="Inference image size. Default: 640")
    parser.add_argument("--conf", type=float, default=0.25, help="Confidence threshold. Default: 0.25")
    parser.add_argument("--iou", type=float, default=0.45, help="NMS IoU threshold. Default: 0.45")
    parser.add_argument("--device", type=str, default=None, help="Device, e.g. cpu, 0. Default: ultralytics auto")
    parser.add_argument("--show", action="store_true", help="Show result window.")
    parser.add_argument("--save", action="store_true", help="Save visualized predictions.")
    parser.add_argument("--project", type=str, default="runs/predict", help="Output project dir. Default: runs/predict")
    parser.add_argument("--name", type=str, default="stair_handrail_pc", help="Output run name.")
    parser.add_argument("--print-boxes", action="store_true", help="Print detected boxes to terminal.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if not args.weights.exists():
        raise FileNotFoundError(f"Weights not found: {args.weights}")

    try:
        from ultralytics import YOLO
    except ImportError as exc:
        raise ImportError("ultralytics is not installed. Run: pip install ultralytics") from exc

    model = YOLO(str(args.weights))
    source = parse_source(args.source)

    results = model.predict(
        source=source,
        imgsz=args.imgsz,
        conf=args.conf,
        iou=args.iou,
        device=args.device,
        show=args.show,
        save=args.save,
        project=args.project,
        name=args.name,
        verbose=True,
        stream=False,
    )

    if args.print_boxes:
        names = model.names
        for image_index, result in enumerate(results):
            print(f"\n[Image {image_index}] {getattr(result, 'path', '')}")
            if result.boxes is None or len(result.boxes) == 0:
                print("  no detections")
                continue
            for box in result.boxes:
                cls_id = int(box.cls.item())
                conf = float(box.conf.item())
                xyxy = box.xyxy[0].tolist()
                class_name = names.get(cls_id, str(cls_id)) if isinstance(names, dict) else str(cls_id)
                print(f"  {class_name} conf={conf:.4f} xyxy={[round(x, 2) for x in xyxy]}")

    print("Inference completed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
