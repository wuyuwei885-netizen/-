#!/usr/bin/env python3
"""
Split raw YOLO dataset into train/val/test with synchronized images and labels.

Functions:
- Split images and labels by 7:2:1 by default.
- Keep image-label pairs synchronized.
- Support empty label files for negative samples.
- Create empty label files when images have no label, unless --no-create-empty-labels is used.
- Default random seed: 42.

Example:
    python scripts/split_dataset.py \
      --src-images datasets/raw/images \
      --src-labels datasets/raw/labels \
      --out-dataset datasets/stair_handrail
"""

from __future__ import annotations

import argparse
import random
import shutil
from dataclasses import dataclass
from pathlib import Path

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


@dataclass(frozen=True)
class Pair:
    image: Path
    label: Path | None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Split YOLO dataset into train/val/test.")
    parser.add_argument("--src-images", type=Path, required=True, help="Raw image directory.")
    parser.add_argument("--src-labels", type=Path, required=True, help="Raw label directory.")
    parser.add_argument("--out-dataset", type=Path, default=Path("datasets/stair_handrail"), help="Output dataset root.")
    parser.add_argument("--train-ratio", type=float, default=0.7, help="Train ratio. Default: 0.7")
    parser.add_argument("--val-ratio", type=float, default=0.2, help="Validation ratio. Default: 0.2")
    parser.add_argument("--test-ratio", type=float, default=0.1, help="Test ratio. Default: 0.1")
    parser.add_argument("--seed", type=int, default=42, help="Random seed. Default: 42")
    parser.add_argument("--move", action="store_true", help="Move files instead of copying them.")
    parser.add_argument("--overwrite", action="store_true", help="Remove existing output dataset before splitting.")
    parser.add_argument(
        "--no-create-empty-labels",
        action="store_true",
        help="Do not create empty labels for images without labels.",
    )
    return parser.parse_args()


def validate_ratios(train: float, val: float, test: float) -> None:
    total = train + val + test
    if abs(total - 1.0) > 1e-6:
        raise ValueError(f"Ratios must sum to 1.0, got {total}")
    if min(train, val, test) < 0:
        raise ValueError("Ratios must be non-negative.")


def find_images(src_images: Path) -> list[Path]:
    if not src_images.exists():
        raise FileNotFoundError(f"Image directory not found: {src_images}")
    return sorted(p for p in src_images.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def build_pairs(src_images: Path, src_labels: Path) -> list[Pair]:
    images = find_images(src_images)
    pairs: list[Pair] = []
    for image in images:
        rel_stem = image.relative_to(src_images).with_suffix("")
        label = src_labels / f"{rel_stem}.txt"
        pairs.append(Pair(image=image, label=label if label.exists() else None))
    return pairs


def prepare_output(out_dataset: Path, overwrite: bool) -> None:
    if out_dataset.exists() and overwrite:
        shutil.rmtree(out_dataset)
    for split in ("train", "val", "test"):
        (out_dataset / "images" / split).mkdir(parents=True, exist_ok=True)
        (out_dataset / "labels" / split).mkdir(parents=True, exist_ok=True)


def split_pairs(pairs: list[Pair], train_ratio: float, val_ratio: float, seed: int) -> dict[str, list[Pair]]:
    shuffled = pairs[:]
    random.Random(seed).shuffle(shuffled)
    n_total = len(shuffled)
    n_train = int(n_total * train_ratio)
    n_val = int(n_total * val_ratio)
    return {
        "train": shuffled[:n_train],
        "val": shuffled[n_train : n_train + n_val],
        "test": shuffled[n_train + n_val :],
    }


def unique_destination(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    idx = 1
    while True:
        candidate = parent / f"{stem}_{idx}{suffix}"
        if not candidate.exists():
            return candidate
        idx += 1


def copy_or_move(src: Path, dst: Path, move: bool) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if move:
        shutil.move(str(src), str(dst))
    else:
        shutil.copy2(src, dst)


def write_split(
    split_name: str,
    pairs: list[Pair],
    src_images: Path,
    out_dataset: Path,
    move: bool,
    create_empty_labels: bool,
) -> tuple[int, int]:
    copied_images = 0
    created_empty_labels = 0

    for pair in pairs:
        rel_image = pair.image.relative_to(src_images)
        image_dst = unique_destination(out_dataset / "images" / split_name / rel_image.name)
        label_dst = out_dataset / "labels" / split_name / f"{image_dst.stem}.txt"

        copy_or_move(pair.image, image_dst, move=move)
        copied_images += 1

        if pair.label is not None:
            copy_or_move(pair.label, label_dst, move=move)
        elif create_empty_labels:
            label_dst.write_text("", encoding="utf-8")
            created_empty_labels += 1
        else:
            print(f"WARNING: no label for {pair.image}; skipped label creation.")

    return copied_images, created_empty_labels


def main() -> int:
    args = parse_args()
    validate_ratios(args.train_ratio, args.val_ratio, args.test_ratio)

    pairs = build_pairs(args.src_images, args.src_labels)
    if not pairs:
        raise RuntimeError(f"No images found in {args.src_images}")

    prepare_output(args.out_dataset, args.overwrite)
    split_map = split_pairs(pairs, args.train_ratio, args.val_ratio, args.seed)

    total_empty = 0
    for split, split_pairs_list in split_map.items():
        copied, empty = write_split(
            split_name=split,
            pairs=split_pairs_list,
            src_images=args.src_images,
            out_dataset=args.out_dataset,
            move=args.move,
            create_empty_labels=not args.no_create_empty_labels,
        )
        total_empty += empty
        print(f"{split}: {copied} images, {empty} empty labels created")

    print("\nDone.")
    print(f"Output dataset: {args.out_dataset}")
    print(f"Total images: {len(pairs)}")
    print(f"Empty labels created: {total_empty}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
