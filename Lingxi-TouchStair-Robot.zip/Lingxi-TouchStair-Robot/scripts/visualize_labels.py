#!/usr/bin/env python3
"""Visualize YOLO labels on images for quick annotation quality inspection."""

from __future__ import annotations

import argparse
from pathlib import Path
import cv2

CLASS_NAMES = {0: "handrail", 1: "stairs"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def parse_args():
    parser = argparse.ArgumentParser(description="Visualize YOLO labels.")
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("outputs/label_vis"))
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    images = sorted(p for p in args.images.iterdir() if p.suffix.lower() in IMAGE_EXTS)
    for image_path in images:
        img = cv2.imread(str(image_path))
        if img is None:
            print(f"WARNING: failed to read {image_path}")
            continue
        h, w = img.shape[:2]
        label_path = args.labels / f"{image_path.stem}.txt"
        if label_path.exists() and label_path.read_text(encoding="utf-8", errors="ignore").strip():
            for line in label_path.read_text(encoding="utf-8", errors="ignore").splitlines():
                parts = line.strip().split()
                if len(parts) != 5:
                    continue
                cls, xc, yc, bw, bh = int(float(parts[0])), *map(float, parts[1:])
                x1 = int((xc - bw / 2) * w)
                y1 = int((yc - bh / 2) * h)
                x2 = int((xc + bw / 2) * w)
                y2 = int((yc + bh / 2) * h)
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(img, CLASS_NAMES.get(cls, str(cls)), (x1, max(20, y1 - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.imwrite(str(args.output / image_path.name), img)
    print(f"Saved visualizations to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
