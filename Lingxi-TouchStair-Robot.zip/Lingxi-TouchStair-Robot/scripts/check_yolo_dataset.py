#!/usr/bin/env python3
"""
Check YOLO detection dataset for Lingxi TouchStair Robot.

Functions:
- Check whether images and labels match one-to-one.
- Check empty label files. Empty labels are allowed for negative samples.
- Check whether class ids only contain allowed ids, default: 0 and 1.
- Check whether every non-empty label row has 5 columns.
- Check whether bbox values are normalized into [0, 1].
- Generate an error report.

Example:
    python scripts/check_yolo_dataset.py --dataset datasets/stair_handrail
    python scripts/check_yolo_dataset.py --dataset datasets/stair_handrail --report reports/dataset_check.txt
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
DEFAULT_SPLITS = ("train", "val", "test")


@dataclass
class CheckResult:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    num_images: int = 0
    num_labels: int = 0
    num_empty_labels: int = 0
    num_boxes: int = 0

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check YOLO dataset integrity.")
    parser.add_argument(
        "--dataset",
        type=Path,
        required=True,
        help="Dataset root, e.g. datasets/stair_handrail",
    )
    parser.add_argument(
        "--splits",
        nargs="+",
        default=list(DEFAULT_SPLITS),
        help="Dataset splits to check. Default: train val test",
    )
    parser.add_argument(
        "--allowed-classes",
        type=int,
        nargs="+",
        default=[0, 1],
        help="Allowed class ids. Default: 0 1",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=None,
        help="Optional report output path.",
    )
    parser.add_argument(
        "--strict-empty-label",
        action="store_true",
        help="Treat empty label files as errors. By default they are warnings because negative samples are allowed.",
    )
    return parser.parse_args()


def iter_images(directory: Path) -> Iterable[Path]:
    if not directory.exists():
        return []
    return sorted(p for p in directory.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def iter_labels(directory: Path) -> Iterable[Path]:
    if not directory.exists():
        return []
    return sorted(p for p in directory.rglob("*.txt") if p.is_file())


def read_label_lines(label_path: Path) -> list[str]:
    try:
        return [line.strip() for line in label_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    except UnicodeDecodeError:
        return [line.strip() for line in label_path.read_text(encoding="utf-8", errors="ignore").splitlines() if line.strip()]


def check_label_file(
    label_path: Path,
    allowed_classes: set[int],
    result: CheckResult,
    strict_empty_label: bool,
) -> None:
    raw_text = label_path.read_text(encoding="utf-8", errors="ignore")
    if raw_text.strip() == "":
        result.num_empty_labels += 1
        msg = f"EMPTY_LABEL: {label_path} is empty. This is valid only for negative samples."
        if strict_empty_label:
            result.errors.append(msg)
        else:
            result.warnings.append(msg)
        return

    lines = read_label_lines(label_path)
    for line_no, line in enumerate(lines, start=1):
        parts = line.split()
        if len(parts) != 5:
            result.errors.append(
                f"INVALID_COLUMN_COUNT: {label_path}:{line_no} has {len(parts)} columns, expected 5. Line: {line}"
            )
            continue

        class_raw, *bbox_raw = parts
        try:
            class_id = int(float(class_raw))
        except ValueError:
            result.errors.append(
                f"INVALID_CLASS_ID: {label_path}:{line_no} class id is not numeric: {class_raw}"
            )
            continue

        if class_id not in allowed_classes:
            result.errors.append(
                f"CLASS_ID_OUT_OF_RANGE: {label_path}:{line_no} class id {class_id} not in {sorted(allowed_classes)}"
            )

        try:
            bbox = [float(x) for x in bbox_raw]
        except ValueError:
            result.errors.append(
                f"INVALID_BBOX_VALUE: {label_path}:{line_no} bbox contains non-numeric value. Line: {line}"
            )
            continue

        x_center, y_center, width, height = bbox
        for name, value in zip(("x_center", "y_center", "width", "height"), bbox):
            if not 0.0 <= value <= 1.0:
                result.errors.append(
                    f"BBOX_OUT_OF_RANGE: {label_path}:{line_no} {name}={value} is not in [0, 1]."
                )

        if width <= 0 or height <= 0:
            result.errors.append(
                f"INVALID_BBOX_SIZE: {label_path}:{line_no} width={width}, height={height}; both must be > 0."
            )

        result.num_boxes += 1


def check_split(dataset_root: Path, split: str, allowed_classes: set[int], strict_empty_label: bool) -> CheckResult:
    result = CheckResult()
    image_dir = dataset_root / "images" / split
    label_dir = dataset_root / "labels" / split

    if not image_dir.exists():
        result.errors.append(f"MISSING_IMAGE_DIR: {image_dir} does not exist.")
        return result

    if not label_dir.exists():
        result.errors.append(f"MISSING_LABEL_DIR: {label_dir} does not exist.")
        return result

    images = list(iter_images(image_dir))
    labels = list(iter_labels(label_dir))
    result.num_images = len(images)
    result.num_labels = len(labels)

    image_stems = {p.relative_to(image_dir).with_suffix("").as_posix(): p for p in images}
    label_stems = {p.relative_to(label_dir).with_suffix("").as_posix(): p for p in labels}

    for stem, image_path in sorted(image_stems.items()):
        expected_label = label_dir / f"{stem}.txt"
        if stem not in label_stems:
            result.errors.append(f"MISSING_LABEL: image {image_path} has no label {expected_label}")

    for stem, label_path in sorted(label_stems.items()):
        if stem not in image_stems:
            result.errors.append(f"MISSING_IMAGE: label {label_path} has no matching image in {image_dir}")
        check_label_file(label_path, allowed_classes, result, strict_empty_label)

    return result


def format_report(results: dict[str, CheckResult]) -> str:
    lines: list[str] = []
    lines.append("YOLO Dataset Check Report")
    lines.append("=" * 80)

    total_errors = 0
    total_warnings = 0
    total_images = 0
    total_labels = 0
    total_boxes = 0
    total_empty = 0

    for split, result in results.items():
        total_errors += len(result.errors)
        total_warnings += len(result.warnings)
        total_images += result.num_images
        total_labels += result.num_labels
        total_boxes += result.num_boxes
        total_empty += result.num_empty_labels

        lines.append(f"\n[{split}]")
        lines.append(f"images       : {result.num_images}")
        lines.append(f"labels       : {result.num_labels}")
        lines.append(f"boxes        : {result.num_boxes}")
        lines.append(f"empty labels : {result.num_empty_labels}")
        lines.append(f"errors       : {len(result.errors)}")
        lines.append(f"warnings     : {len(result.warnings)}")

        if result.errors:
            lines.append("\nErrors:")
            lines.extend(f"  - {msg}" for msg in result.errors)

        if result.warnings:
            lines.append("\nWarnings:")
            lines.extend(f"  - {msg}" for msg in result.warnings)

    lines.append("\n" + "=" * 80)
    lines.append("Summary")
    lines.append(f"total images       : {total_images}")
    lines.append(f"total labels       : {total_labels}")
    lines.append(f"total boxes        : {total_boxes}")
    lines.append(f"total empty labels : {total_empty}")
    lines.append(f"total errors       : {total_errors}")
    lines.append(f"total warnings     : {total_warnings}")
    lines.append("status             : OK" if total_errors == 0 else "status             : FAILED")
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    dataset_root = args.dataset
    allowed_classes = set(args.allowed_classes)

    results = {
        split: check_split(dataset_root, split, allowed_classes, args.strict_empty_label)
        for split in args.splits
    }
    report = format_report(results)
    print(report)

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(report, encoding="utf-8")
        print(f"\nReport saved to: {args.report}")

    has_errors = any(not result.ok for result in results.values())
    return 1 if has_errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
