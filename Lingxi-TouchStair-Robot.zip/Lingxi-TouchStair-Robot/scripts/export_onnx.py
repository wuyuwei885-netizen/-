#!/usr/bin/env python3
"""
Export Ultralytics YOLO .pt weights to ONNX.

Default settings are selected for the Lingxi TouchStair Robot MVP:
- imgsz: 640
- opset: 11

Example:
    python scripts/export_onnx.py --weights runs/detect/train/weights/best.pt --imgsz 640 --opset 11
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export YOLO .pt model to ONNX.")
    parser.add_argument("--weights", type=Path, required=True, help="Path to best.pt or other YOLO weights.")
    parser.add_argument("--imgsz", type=int, default=640, help="Export image size. Default: 640")
    parser.add_argument("--opset", type=int, default=11, help="ONNX opset. Default: 11")
    parser.add_argument("--device", type=str, default="cpu", help="Export device. Default: cpu")
    parser.add_argument("--output", type=Path, default=None, help="Optional output ONNX path.")
    parser.add_argument("--dynamic", action="store_true", help="Export with dynamic axes. For RDK X5, fixed shape is usually preferred.")
    parser.add_argument("--simplify", action="store_true", help="Simplify ONNX during export if supported.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if not args.weights.exists():
        raise FileNotFoundError(f"Weights not found: {args.weights}")

    try:
        from ultralytics import YOLO
    except ImportError as exc:
        raise ImportError("ultralytics is not installed. Run: pip install ultralytics") from exc

    model = YOLO(str(args.weights))
    exported_path = model.export(
        format="onnx",
        imgsz=args.imgsz,
        opset=args.opset,
        device=args.device,
        dynamic=args.dynamic,
        simplify=args.simplify,
    )

    exported_path = Path(exported_path)
    final_path = exported_path

    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        if exported_path.resolve() != args.output.resolve():
            shutil.copy2(exported_path, args.output)
        final_path = args.output

    print("ONNX export completed.")
    print(f"weights : {args.weights}")
    print(f"imgsz   : {args.imgsz}")
    print(f"opset   : {args.opset}")
    print(f"output  : {final_path}")
    print("\nNext step: use OpenExplorer / hb_compile to convert ONNX to RDK X5 BIN model.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
