#!/usr/bin/env python3
"""
Rename images and synchronized YOLO label files into clean English numbered names.

Functions:
- Rename Chinese names, spaces and special-character filenames into English ids.
- Rename matching .txt label files synchronously.
- Generate rename_map.csv.

Example:
    python scripts/rename_images.py --images datasets/raw/images --labels datasets/raw/labels --prefix stair
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Rename images and labels to clean English numbered filenames.")
    parser.add_argument("--images", type=Path, required=True, help="Image directory.")
    parser.add_argument("--labels", type=Path, required=True, help="Label directory.")
    parser.add_argument("--prefix", type=str, default="stair", help="New filename prefix. Default: stair")
    parser.add_argument("--digits", type=int, default=6, help="Number digits. Default: 6")
    parser.add_argument("--start-index", type=int, default=1, help="Start index. Default: 1")
    parser.add_argument("--map-file", type=Path, default=Path("rename_map.csv"), help="CSV map output path.")
    parser.add_argument("--dry-run", action="store_true", help="Only print and write map, do not rename files.")
    return parser.parse_args()


def find_images(image_dir: Path) -> list[Path]:
    if not image_dir.exists():
        raise FileNotFoundError(f"Image directory not found: {image_dir}")
    return sorted(p for p in image_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def make_plan(images: list[Path], labels_dir: Path, prefix: str, digits: int, start_index: int) -> list[dict[str, str]]:
    plan: list[dict[str, str]] = []
    for offset, image in enumerate(images):
        idx = start_index + offset
        new_stem = f"{prefix}_{idx:0{digits}d}"
        new_image = image.with_name(f"{new_stem}{image.suffix.lower()}")
        old_label = labels_dir / f"{image.stem}.txt"
        new_label = labels_dir / f"{new_stem}.txt"
        plan.append(
            {
                "old_image": str(image),
                "new_image": str(new_image),
                "old_label": str(old_label) if old_label.exists() else "",
                "new_label": str(new_label) if old_label.exists() else "",
                "label_status": "found" if old_label.exists() else "missing",
            }
        )
    return plan


def check_conflicts(plan: list[dict[str, str]]) -> None:
    new_images = [row["new_image"] for row in plan]
    new_labels = [row["new_label"] for row in plan if row["new_label"]]
    if len(new_images) != len(set(new_images)):
        raise RuntimeError("New image names contain duplicates.")
    if len(new_labels) != len(set(new_labels)):
        raise RuntimeError("New label names contain duplicates.")

    old_images = {row["old_image"] for row in plan}
    old_labels = {row["old_label"] for row in plan if row["old_label"]}

    for new_path in new_images + new_labels:
        if not new_path:
            continue
        p = Path(new_path)
        if p.exists() and str(p) not in old_images and str(p) not in old_labels:
            raise FileExistsError(f"Destination already exists and is not part of rename plan: {p}")


def write_map(plan: list[dict[str, str]], map_file: Path) -> None:
    map_file.parent.mkdir(parents=True, exist_ok=True)
    with map_file.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["old_image", "new_image", "old_label", "new_label", "label_status"])
        writer.writeheader()
        writer.writerows(plan)


def rename_with_temp(plan: list[dict[str, str]]) -> None:
    temp_pairs: list[tuple[Path, Path]] = []

    for idx, row in enumerate(plan):
        old_image = Path(row["old_image"])
        tmp_image = old_image.with_name(f".__tmp_rename_image_{idx}{old_image.suffix}")
        old_image.rename(tmp_image)
        temp_pairs.append((tmp_image, Path(row["new_image"])))

        if row["old_label"]:
            old_label = Path(row["old_label"])
            tmp_label = old_label.with_name(f".__tmp_rename_label_{idx}.txt")
            old_label.rename(tmp_label)
            temp_pairs.append((tmp_label, Path(row["new_label"])))

    for tmp, final in temp_pairs:
        final.parent.mkdir(parents=True, exist_ok=True)
        tmp.rename(final)


def main() -> int:
    args = parse_args()
    images = find_images(args.images)
    if not images:
        raise RuntimeError(f"No images found in {args.images}")

    args.labels.mkdir(parents=True, exist_ok=True)
    plan = make_plan(images, args.labels, args.prefix, args.digits, args.start_index)
    check_conflicts(plan)
    write_map(plan, args.map_file)

    print(f"Found images: {len(images)}")
    print(f"Rename map saved to: {args.map_file}")

    missing_labels = sum(1 for row in plan if row["label_status"] == "missing")
    if missing_labels:
        print(f"WARNING: {missing_labels} images have no matching label file.")

    if args.dry_run:
        print("Dry run enabled. No files were renamed.")
        return 0

    rename_with_temp(plan)
    print("Rename completed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
