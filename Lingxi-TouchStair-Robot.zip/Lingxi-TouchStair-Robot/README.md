# Lingxi TouchStair Robot

> 灵犀·触行：面向校园楼梯场景的视觉-雷达融合仿生触手上楼机器人  
> GitHub repository: `Lingxi-TouchStair-Robot`

本项目是一个基于 **RDK X5** 的端侧视觉识别与楼梯环境感知项目，服务于“仿生柔性触手上楼机器人”。项目目标不是单纯做一个摄像头检测 Demo，而是围绕真实校园楼梯、楼道、栏杆环境，完成从数据采集、数据标注、YOLO 模型训练、ONNX 导出、RDK X5 BPU 部署，到后续 ROS2 视觉-雷达融合的完整工程链路。

当前核心任务是识别校园楼梯场景中的 `stairs` 和 `handrail` 两类目标，并将 YOLO 模型部署到 RDK X5 的 BPU 上进行本地摄像头实时检测。后续计划融合 **Tmini Plus ToF 激光雷达** 的距离与空间结构信息，为机器人判断台阶位置、识别栏杆、辅助抓握和上楼运动控制提供感知输入。

本仓库只整理“灵犀·触行”机器人项目相关内容，不包含其他无关项目代码。

---

## 1. Project Goals

- 识别校园楼梯、楼道、栏杆场景中的 `stairs` 和 `handrail`。
- 使用 Label Studio 构建 YOLO 检测数据集。
- 使用 Ultralytics YOLO 训练轻量化目标检测模型。
- 将模型从 `best.pt` 导出为 ONNX。
- 使用 OpenExplorer / `hb_compile` 转换为 RDK X5 BPU 可运行的 BIN 模型。
- 在 RDK X5 上接入 USB 摄像头 / IMX219 / C100 摄像头并完成实时检测。
- 后续融合 Tmini Plus ToF 激光雷达 `/scan` 数据。
- 为仿生柔性触手上楼机器人提供“楼梯位置、栏杆位置、目标置信度、距离估计”等感知输入。

---

## 2. Application Scenarios

- 校园楼梯搬运辅助。
- 老旧教学楼、宿舍楼、实验楼等无电梯环境。
- 小型机器人楼梯通行与巡检。
- 楼梯栏杆辅助抓握与仿生触手支撑。
- 仿生柔性触手机器人的真实环境感知。

---

## 3. Innovation Points

1. **端侧 AI 部署链路**  
   项目围绕 `YOLO -> ONNX -> BIN -> BPU` 形成端侧部署流程，而不是只在 PC 上运行模型。

2. **楼梯 + 栏杆双目标识别**  
   检测目标不是通用 COCO 类别，而是面向楼梯机器人任务定制的 `stairs` 和 `handrail`。

3. **视觉与 ToF 激光雷达融合**  
   视觉提供语义类别，雷达提供距离与空间结构，两者互补，为机器人上楼和触手抓握提供更稳定输入。

4. **仿生柔性触手机构与楼梯场景结合**  
   项目不是单纯视觉识别，而是服务于柔性触手抓握栏杆、辅助机器人上楼的系统级任务。

5. **面向真实校园楼梯场景**  
   数据来自真实校园楼梯、楼道、栏杆、墙面、地面等场景，而不是纯仿真环境。

---

## 4. System Architecture

```mermaid
graph TD
A[Camera] --> B[YOLO Stair/Handrail Detection]
B --> C[RDK X5 BPU Inference]
D[Tmini Plus ToF LiDAR] --> E[ROS2 LaserScan]
C --> F[Vision-Radar Fusion]
E --> F
F --> G[Robot Motion / Flexible Tentacle Control]
```

---

## 5. Tech Stack

- Python
- OpenCV
- Ultralytics YOLO
- ROS2
- RDK X5
- OpenExplorer
- `hb_compile`
- Label Studio
- Tmini Plus ToF LiDAR

---

## 6. Repository Structure

```text
Lingxi-TouchStair-Robot/
├── README.md
├── LICENSE
├── .gitignore
├── requirements.txt
├── docs/
│   ├── project_overview.md
│   ├── technical_route.md
│   ├── errors_and_solutions.md
│   ├── thinking_process.md
│   ├── dataset_guide.md
│   ├── training_guide.md
│   ├── rdk_x5_deployment.md
│   ├── fusion_design.md
│   └── troubleshooting.md
├── configs/
│   ├── data.yaml
│   ├── train_yolo11n.yaml
│   └── rdk_x5_compile_config.yaml
├── scripts/
│   ├── check_yolo_dataset.py
│   ├── split_dataset.py
│   ├── rename_images.py
│   ├── export_onnx.py
│   └── visualize_labels.py
├── src/
│   ├── vision/
│   │   ├── camera_test.py
│   │   ├── yolo_infer_pc.py
│   │   └── postprocess.py
│   ├── fusion/
│   │   ├── fusion_score.py
│   │   └── radar_vision_fusion_node.py
│   └── ros2_nodes/
│       ├── stair_detection_node.py
│       └── stair_fusion_node.py
├── models/
│   ├── README.md
│   └── placeholder.txt
├── datasets/
│   ├── README.md
│   └── example/
│       ├── images/
│       └── labels/
└── assets/
    ├── architecture.png
    ├── pipeline.png
    └── demo_placeholder.png
```

---

## 7. Quick Start

### 7.1 Clone repository

```bash
git clone https://github.com/你的用户名/Lingxi-TouchStair-Robot.git
cd Lingxi-TouchStair-Robot
```

### 7.2 Create virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

Linux / WSL / Ubuntu:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 7.3 Prepare dataset

YOLO 数据集目录应为：

```text
datasets/stair_handrail/
├── images/
│   ├── train/
│   ├── val/
│   └── test/
└── labels/
    ├── train/
    ├── val/
    └── test/
```

类别映射固定为：

```yaml
names:
  0: handrail
  1: stairs
```

### 7.4 Check dataset

```bash
python scripts/check_yolo_dataset.py --dataset datasets/stair_handrail
```

该脚本会检查：

- 图片与标签是否一一对应。
- label 文件是否为空。
- 类别 id 是否只包含 `0` 和 `1`。
- 每一行 bbox 是否为 5 列。
- YOLO 坐标是否在 `0~1` 范围内。

### 7.5 Split dataset

如果你有原始图片和标签目录，可以按 7:2:1 划分：

```bash
python scripts/split_dataset.py \
  --src-images datasets/raw/images \
  --src-labels datasets/raw/labels \
  --out-dataset datasets/stair_handrail \
  --train-ratio 0.7 \
  --val-ratio 0.2 \
  --test-ratio 0.1 \
  --seed 42
```

### 7.6 Rename images and labels

为避免中文路径、空格、特殊字符导致训练或导出异常，建议统一英文编号：

```bash
python scripts/rename_images.py \
  --images datasets/raw/images \
  --labels datasets/raw/labels \
  --prefix stair \
  --digits 6
```

脚本会生成：

```text
rename_map.csv
```

### 7.7 Train YOLO model

MVP 推荐先使用 YOLO11n：

```bash
yolo detect train data=configs/data.yaml model=yolo11n.pt epochs=100 imgsz=640 batch=16
```

训练完成后，核心权重通常位于：

```text
runs/detect/train/weights/best.pt
```

如果 YOLO11n 精度不足，再尝试 YOLO11s：

```bash
yolo detect train data=configs/data.yaml model=yolo11s.pt epochs=100 imgsz=640 batch=16
```

### 7.8 PC inference before board deployment

```bash
python src/vision/yolo_infer_pc.py \
  --weights runs/detect/train/weights/best.pt \
  --source datasets/stair_handrail/images/test \
  --imgsz 640 \
  --conf 0.25 \
  --show
```

摄像头测试：

```bash
python src/vision/yolo_infer_pc.py --weights runs/detect/train/weights/best.pt --source 0 --show
```

### 7.9 Export ONNX

```bash
python scripts/export_onnx.py \
  --weights runs/detect/train/weights/best.pt \
  --imgsz 640 \
  --opset 11
```

输出示例：

```text
runs/detect/train/weights/best.onnx
```

### 7.10 RDK X5 deployment

RDK X5 BPU 部署链路：

```text
best.pt -> best.onnx -> handrail_stairs_yolo11n.bin -> RDK X5 BPU inference
```

转换 BIN 的配置参考：

```text
configs/rdk_x5_compile_config.yaml
```

具体部署流程见：

- [`docs/rdk_x5_deployment.md`](docs/rdk_x5_deployment.md)
- [`docs/troubleshooting.md`](docs/troubleshooting.md)

### 7.11 Camera test

```bash
python src/vision/camera_test.py --camera 0
```

按 `q` 退出。

---

## 8. Dataset Format

YOLO 标签格式：

```text
<class_id> <x_center> <y_center> <width> <height>
```

示例：

```text
0 0.5163 0.4231 0.3312 0.2148
1 0.4820 0.6725 0.8100 0.3850
```

类别含义：

| class_id | class_name |
|---:|---|
| 0 | handrail |
| 1 | stairs |

负样本允许存在空标签文件，例如：

```text
datasets/stair_handrail/images/train/corridor_000001.jpg
datasets/stair_handrail/labels/train/corridor_000001.txt
```

其中 `corridor_000001.txt` 可以为空，但必须存在，便于训练和检查脚本保持同步。

---

## 9. Project Review

项目复盘文档：

- [`docs/errors_and_solutions.md`](docs/errors_and_solutions.md)：记录数据、训练、导出、部署、摄像头、融合阶段踩过的坑。
- [`docs/thinking_process.md`](docs/thinking_process.md)：记录为什么先做视觉检测、为什么选择 RDK X5、为什么做负样本、为什么重构 GitHub。
- [`docs/technical_route.md`](docs/technical_route.md)：完整技术路线。

---

## 10. Current Progress

- [x] 明确楼梯 / 栏杆检测任务
- [x] 完成 Label Studio 标注流程
- [x] 完成 YOLO 数据集整理
- [x] 完成 YOLO 模型训练
- [x] 完成 ONNX 导出
- [x] 初步完成 RDK X5 BPU 部署链路
- [ ] 完善 Tmini Plus 雷达融合
- [ ] 完善栏杆左右 / 高度判断
- [ ] 完善机器人运动闭环控制
- [ ] 增加真实楼梯场景实验数据

> 注：未完成部分均标注为后续计划，不在 README 中包装成已完成成果。

---

## 11. GitHub Release Rules

不要上传大文件和私有数据：

- 不上传 `best.pt`。
- 不上传 `.onnx`。
- 不上传 `.bin`。
- 不上传完整数据集。
- 不上传视频文件。
- `models/` 只保留说明文件。
- `datasets/` 只保留示例结构。

---

## 12. License

This project is released under the MIT License. See [`LICENSE`](LICENSE) for details.
